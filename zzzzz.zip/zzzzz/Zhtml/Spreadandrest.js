// Spread 
const numbers = [1, 2, 3];
const colors = ['red', 'blue', 'green'];

const combined = [...numbers, ...colors];
console.log(combined);

const copy = [...numbers];
console.log(copy); 


function sum(a, b, c) {
  return a + b + c;
}

const values = [1, 2, 3];
const total = sum(...values);
console.log(total); 

// Rest Operator


function multiply(multiplier, ...numbers) {
  return numbers.map(num => num * multiplier);
}

const result = multiply(2, 1, 2, 3, 4);
console.log(result); // [2, 4, 6, 8]

//  destructuring
const person = {
  fname: 'Vivek',
  age: 23,
  city: 'pune'
};

const { fname, ...details } = person;
console.log(fname); // Output: 'Vivek'
console.log(details); // Output: { age: 25, city: 'Pune' }