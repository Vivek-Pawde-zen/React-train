const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];


const chkeven = numbers.every(num => num % 2 === 0);
console.log(chkeven); // Output will be  false

const evenNumbers = numbers.filter(num => num % 2 === 0);
console.log(evenNumbers); // Output is even array : [2, 4, 6, 8, 10]

const firstEvenNumber = numbers.find(num => num % 7 === 0);
console.log(firstEvenNumber); // Output: 7

// findIndex
const firstEvenNumberIndex = numbers.findIndex(num => num % 9=== 0);
console.log(firstEvenNumberIndex);


const lastEvenNumber = numbers.findLast(num => num % 2 === 0);
console.log(lastEvenNumber); 

// forEach
numbers.forEach(num => console.log(num)); // Output: 1 2 3 4 5 6 7 8 9 10

const double = numbers.map(num => num * 2);
console.log(double); 

// slice
const sliceArray = numbers.slice(2, 5);
console.log(sliceArray); // Output: [3, 4, 5]

const spliceArray = numbers.splice(1, 3);
console.log(spliceArray); 
console.log(numbers);