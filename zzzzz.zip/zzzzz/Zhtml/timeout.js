console.log(" setTimeout...");
const timeoutId = setTimeout(() => {
  console.log("Timeout completed! settimeout is executed after 8 seconds.");
}, 8000);

// clearTimeout(timeoutId);

let counter = 0;
console.log("setInterval...");
const intervalId = setInterval(() => {
  counter++;
  console.log(`Interval ${counter}: This is executed every 1 second.`);
  console.log(`____________________________________________________`);
  if (counter === 10) {
    console.log("10 seconds elapsed. stopping setInterval now");
    clearInterval(intervalId); // To stop the setInterval after 5 seconds
  }
}, 1000);