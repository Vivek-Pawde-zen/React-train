
const date = new Date();

const currentDate = date.getDate();

const currentDay = date.getDay();

const currentYear = date.getFullYear();

const currentHour = date.getHours();

const currentMilliseconds = date.getMilliseconds();

const currentMinute = date.getMinutes();

const currentMonth = date.getMonth();

const currentSecond = date.getSeconds();

// Getting the time in ms since 1970
const currentTime = date.getTime();

const timeZoneOffset = date.getTimezoneOffset();

const currentUTCDay = date.getUTCDate();

const currentUTCDayOfWeek = date.getUTCDay();

console.log("Current Date:", currentDate);
console.log("Current Day:", currentDay);
console.log("Current Year:", currentYear);
console.log("Current Hour:", currentHour);
console.log("Current Milliseconds:", currentMilliseconds);
console.log("Current Minute:", currentMinute);
console.log("Current Month:", currentMonth);
console.log("Current Second:", currentSecond);
console.log("Current Time:", currentTime);
console.log("Timezone Offset:", timeZoneOffset);
console.log("UTC Date:", currentUTCDay);
console.log("UTC Day of the Week:", currentUTCDayOfWeek);