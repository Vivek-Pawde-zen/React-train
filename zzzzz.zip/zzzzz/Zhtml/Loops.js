"use strict";
var x,y=15,z;
for (x=0;x<10;x++){
    console.log(x);
}



do{
    y+=1;
    console.log("do loop 1st iteration even when condition is not satisfied");

}
while(y<10);


let hrs = 10

if(hrs<9)
{
    console.log("Worklife balance");
}
else{
    console.log("no work life balance");
}

var result = (hrs < 9 )? "Work life balance " : "No Work life balance";
console.log(result);


const obj = {fname:"John", lname:"Doe", age:25};

console.log("All properties of object are as follows: ")
for (let x in obj) {
  console.log(x);
}
const arr = [1,2,3,4];

console.log("All Values of array are as follows: ")
for (let x of arr) {
    console.log(x);
  }


 console.log(Boolean(0)) ;
 console.log(Boolean(3)) ;
 console.log(Boolean(NaN)) ;
 console.log(Boolean("")) ;