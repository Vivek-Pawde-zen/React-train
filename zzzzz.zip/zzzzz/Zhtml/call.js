const person1 = {
    name: 'Alice',
    greeting: function(message) {
      console.log(message + ', ' + this.name);
    }
  };
  
  // Call the greeting function with a specific 'this' value
  person.greeting.call({ name: 'Bob' }, 'Hello'); // Output: Hello, Bob


  const person2 = {
    name: 'Alice',
    greeting: function(message) {
      console.log(message + ', ' + this.name);
    }
  };
  
  // Create a new function with a specific 'this' value
  const greet = person.greeting.bind({ name: 'Bob' });
  
  // Invoke the new function
  greet('Hello'); // Output: Hello, Bob


  const person3 = {
    name: 'Alice',
    greeting: function(message1, message2) {
      console.log(message1 + ', ' + message2 + ', ' + this.name);
    }
  };
  
  // Call the greeting function with multiple arguments using 'apply'
  person.greeting.apply({ name: 'Bob' }, ['Hello', 'How are you?']);
  // Output: Hello, How are you?, Bob