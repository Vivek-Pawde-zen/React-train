const panelSchema1 = require("../schema/panelSchema");
const jwt = require("jsonwebtoken");
const axios = require('axios');
const { response } = require('express');
// Display the List Of panel when URL consists of api panel
getPanel = async (req, res) => {
    axios.get('http://localhost:8080/user/validate', {
        headers: {
            Cookie: "auth-token=" + req.cookies['auth-token'],
            Cookie1: "Refresh_Token=" + req.cookies['Refresh_Token']
        }
    }).then(async (response) => {

        await panelSchema1.find().then(data => {

            res.send(data)
        })
    }).catch(err => {
        //console.log('123')
        res.status(400).send(err)
    })
};

getPanelById = async (req, res) => {
    axios.get('http://localhost:8080/user/validate', {
        headers: {
            Cookie: "auth-token=" + req.cookies['auth-token'],

        }
    }).then(response => {
        //logic for getPanelBySkills
        panelSchema1.findOne({ panelId: req.params.panelId }, function (err, result) {
            if (err) {
                res.sendStatus(403);
            } else {
                res.json({
                    result,
                });
            }
        });
    }).catch(err => {
        res.status(403).send("error occured jjj")
    })
}

getPanelBySkills = async (req, res) => {
    axios.get('http://localhost:8080/user/validate', {
        headers: {
            Cookie: "auth-token=" + req.cookies['auth-token'],
            Cookie1: "Refresh_Token=" + req.cookies['Refresh_Token']
        }
    }).then(response => {
        //logic for getPanelBySkills
        panelSchema1.find({ skills: req.params.skills }, function (err, result) {
            if (err) {
                res.sendStatus(403);
            } else {
                res.json({
                    result,
                });
            }
        });
    }).catch(err => {
        res.status(403).send("error occured jjj")
    })
}

//CREATE Request Handler
//CREATE New panel Information
createPanel = async (req, res) => {
    console.log("success");
    axios.get('http://localhost:8080/user/validate', {
        headers: {
            Cookie: "auth-token=" + req.cookies['auth-token']
        }
    }).then(response => {
        const { panelId, panelName, skills, Interviewer, Active } = req.body;
        console.log(Active);
        const panelinfo = new panelSchema1({ panelId, panelName, skills, Interviewer, Active });
        panelinfo.save().then(() => {
            res.status(201).send(panelinfo);
        });
    }).catch(err => {
        res.status(403).send("error occured")
    })
};

//Update Request Handler
// Update Existing panel Information

const updatePanel = async (req, res) => {
    axios.get('http://localhost:8080/user/validate', {
        headers: {
            Cookie: "auth-token=" + req.cookies['auth-token']
        }
    }).then(response => {
        //logic for getPanelBySkills

        panelSchema1.findOne({ panelId: req.params.panelId }, function (err, result) {
            if (err) throw err;
            if (!result) {
                res.json({
                    message: "Panel with id: " + req.params.panelId + " not found.",
                });
            }
            else {
                if (req.body.panelId != null) {
                    res.send("sorry, you cannot change panel id");
                }
                else {
                    result.panelName = req.body.panelName;
                    result.skills = req.body.skills;
                    result.Interviewer = req.body.Interviewer;
                    result.active = req.body.active;
                }
                result.save(function (err, result) {
                    if (err) throw err;
                    res.json({
                        message: "Successfully updated the panel",
                        panelSchema: result
                    });
                });
            }
        }).catch(err => {
            res.status(400).send("error occured")
        })
    })
}
//Delete Request Handler
// Delete panel Details
const deletePanel = async (req, res) => {
    axios.get('http://localhost:8080/user/validate', {
        headers: {
            Cookie: "auth-token=" + req.cookies['auth-token'],
            Cookie1: "Refresh_Token=" + req.cookies['Refresh_Token']
        }
    }).then(response => {
        //logic for getPanelBySkill
        panelSchema1.findOneAndRemove(
            { panelId: req.params.panelId },
            function (err, result) {
                if (result == null) {
                    res.json({
                        message: "No panel found",
                    });
                }
                else {
                    res.json({
                        message: "Successfully deleted the panel",
                        panelSchema: result,
                    });
                }
            });


    }).catch(err => {
        res.status(400).send("error occured")
    })
}
module.exports = {
    getPanel,
    getPanelBySkills,
    createPanel,
    updatePanel,
    deletePanel,
    getPanelById
};