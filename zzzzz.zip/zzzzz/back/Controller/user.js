require("dotenv").config();

const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
//const auth = require("./../Middleware/auth");
const postUser = require("./../schema/userSchema");
const user = require("./../server.js");


const register = async (req, res) => {
    console.log("Yahs");
    try {
        // Get user input
        const { firstname, lastname,username, password, email, phone, panelName, skills, active } = req.body;
        console.log(req.body.firstname);
        // Validate user input
        if (!(username && email && password && firstname && lastname && phone && panelName && skills && active)) {
            res.status(400).send("All input fields are required");
        }

        //Encrypt user password
        encryptedPassword = await bcrypt.hash(password, 10);

        // Create user in our database
        const user = await postUser.create({
            userRole: 'Panelist',
            username,
            password: encryptedPassword,
            firstname,
            lastname,
            email,
            phone,
            panelName,
            skills,
            active
        });

        // Create token
        const token1 = jwt.sign(
            { user_id: user._id, username },
            process.env.TOKEN_KEY,
            {
                expiresIn: "9h",
            }
        );
        // save user token
        user.token = token1;

        // return new user
        res.status(201).json(user);
        console.log("User registered Successfully");
    } catch (err) {
        console.log(err);
    }
}; // Our route 3 registeration  ends here

///route 1: log in route begins


const login = async (req, res) => {
    // Our login logic starts here
    console.log("In Login");
    try {
        // Get user input
        const { username, password } = req.body;
        console.log(req.body.username);
        postUser.findOne({ username })
            .then(user => {
                if (user) {
                    bcrypt.compare(password, user.password, function (err, result) {

                        if (err) {
                            res.json({
                                error: err
                            })
                        }
                        if (result) {
                            let token1 = jwt.sign({ username: user.username }, 'verySecretValue', { expiresIn: '1h' })
                            let token2 = jwt.sign({ username: user.username }, 'tyhepanelmanagment', { expiresIn: '4h' })
                            res
                                .cookie("auth-token", token1, {
                                    httpOnly: true,
                                    secure: process.env.NODE_ENV === "production",
                                })
                            res
                                .cookie("Refresh_Token", token2, {
                                    httpOnly: true,
                                    secure: process.env.NODE_ENV === "production",
                                })
                            res.status(201).json({
                                message: 'Login Successful',
                                token: token1,
                                refreshToken: token2
                            })

                        } else {
                            res.status(400).send("Blank userName/password")
                        }
                    }
                    )

                } else {
                    res.json({
                        message: 'No User Found'
                    })
                }

            })
    }
    catch (err) {
        console.log(err);
    }
    //route 1 ends here
};

//route no.2=log out route
const logout = async (req, res) => {
    try {
        //console.log(req.cookies['auth-token'])
        var verify = jwt.verify(req.cookies['auth-token'], "verySecretValue")
        postUser.findOne({ username: verify.username }, function (err, result) {
            if (err) {
                res.status(400).send(err)
            }
            else {
                if (result.username == verify.username) {
                    res.clearCookie('auth-token');
                    res.clearCookie('Refresh_Token');
                    res.status(200).send("cleared the cookie1 and 2");
                }
                else {
                    res.status(400).send("error")
                }
            }
        })
    } catch (error) {
        res.status(400).send(error)
    }
}; //route no.2 log out route ends here

//route no.4 :Return user information route
const userInfo = async (req, res) => {
    postUser.find({}, function (err, result) {
        if (err) throw err;
        res.json(result);
    });
};

const validate = function (req, res) {
    try {

        const verify = jwt.verify(req.cookies['auth-token'], 'verySecretValue')
       
        postUser.findOne({ userName: verify.userName }, function (err, result) {
            if (err) {
                res.status(400).send(err)
            }
            else {

                if (result == null) {
                    res.status(401).send(false)
                }
                else {
                    res.status(202).send(verify)
                }
            }
        })

    } catch (err) {
       
       
        // if (err.name == "TokenExpiredError") {
           
        //     const refreshToken = req.headers.cookie1.substring(14)
           
        //     jwt.verify(refreshToken, 'tyhepanelmanagment', (err, result) => {

        //         if (err) {

        //             res.status(400).json({

        //                 err

        //             })

        //         }

        //         else {

        //             let token1 = jwt.sign({ username: result.username }, 'verySecretValue', { expiresIn: '10s' })

        //             const refreshToken = req.headers.cookie1.substring(14)
        //             res.status(200).json({

        //                 message: "Token refreshed",

        //                 token: token1,

        //                 refreshToken: req.cookies['Refresh_Token']

        //             })

        //         }

        //     })

        // }
        res.send(err);

    }
}

module.exports = { register, login, logout, userInfo, validate };