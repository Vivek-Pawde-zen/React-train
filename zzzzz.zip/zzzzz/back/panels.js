require("dotenv").config();
const express = require("express"); //Import Express
//const Joi = require("joi"); //Import Joi
const app = express(); //Create Express Application on the app variable
 //used the json file
const bodyParser = require("body-parser");
const cors = require('cors');
app.use(cors());
const helmet = require("helmet");

var mongoose = require("mongoose");
jsonwebtoken = require("jsonwebtoken");
var cookieParser = require('cookie-parser')

//const panelSchema1 = require("./schema/panelSchema");
const panelRoute = require("./Routes/panel.js");
var dbHost = "mongodb://localhost:27017/PanelManagement";
mongoose.connect(dbHost,{useNewUrlParser:true,useUnifiedTopology:true});

app.use(bodyParser.json());
app.use(express.json());
app.use(helmet());
app.use(cookieParser())

app.get('/',(req,res)=>{
  res.json("hello");
})

const listener = process.env.PORT |4000
 app.listen(listener,"0.0.0.0", () => {
  console.log("Your app is listening on port " + listener);
});

app.use("/panel", panelRoute); 

//module.exports = app;