const { date } = require("joi");
const mongoose = require("mongoose");

const slotSchema = mongoose.Schema({
  slotId: {
    type: String,
    require: true,
  },
  panelName: {
    type: String,
    require: true,
  },
  startDate: {
    type: Date,
    require: true,
  },
  endDate: {
    type: Date,
    require: true,
  },
  starttime: {
    type: String,
    require: true,
  },
  endtime: {
    type: String,
    require: true,
  },
  skills:{
    type: String,
    require:true,
  },
  slotused: {
    type: Boolean,
    require: true,
  },
  active: {
    type: Boolean,
    require: true,
  },
});

// const slot= mongoose.model('slot',slotSchema)

module.exports = mongoose.model("slot", slotSchema);
