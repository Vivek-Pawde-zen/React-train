process.env.NODE_ENV = 'test';

let mongoose = require("mongoose");
let slot = require('./../schema/slotSchema');

let chai = require('chai');
let chaiHttp = require('chai-http');
let server = require('../server');
let should = chai.should();


chai.use(chaiHttp);

describe('slot', () => {
    beforeEach((done) => {
        slot.remove({}, (err) => { 
           done();           
        });        
    });

  describe('/GET slot', () => {
      it('it should GET all the slots', (done) => {
            chai.request(server)
            .get('/slot')
            .end((err, res) => {
                  res.should.have.status(200);
                  res.body.should.be.a('array');
                  res.body.length.should.be.eql(0);
              done();
            });
      });
  });
})
  
  describe('/POST slot', () => {
      it('it should POST a slot ', (done) => {
          let newSlot = {slotId:"1",
            panelName:"java",
            duration:"1 hour",
            slotused:false,
            active:false   
          }
            chai.request(server)
            .post('/slot')
            .send(newSlot)
            .end((err, res) => {
                  res.should.have.status(201);
                  res.body.should.be.a('object');
                  res.body.should.have.property('slotId').eql('1');
                  res.body.should.have.property('panelName').eql('java');
                  res.body.should.have.property('duration').eql('1 hour');
                  res.body.should.have.property('slotused').eql(false);
                  res.body.should.have.property('active').eql(false);
              done();
            });
      });
  });

  describe('/PUT/:slotId', () => {
    it('it should UPDATE a slot given the slotId', (done) => {
        let newslot = new slot({slotId:"3",
        panelName:"java",
        duration:"1 hour",
        slotused:false,
        active:false
        })
        newslot.save((err, slot) => {
              chai.request(server)
              .put('/slot/' + slot.slotId)
              .send({slotId:"3",
                panelName:"java",
                duration:"2 hour",
                slotused:false,
                active:false
               })
              .end((err, res) => {
                    res.should.have.status(200);
                    res.body.should.be.a('object');
                    res.body.should.have.property('message').eql('Successfully updated the slot');
                    res.body.slotSchema.should.have.property('duration').eql('2 hour');
                done();
              });
        });
    });
});
  
  /*
  Test the /DELETE/:id route
  */
 
  describe('/DELETE/:slotId slot', () => {
      it('it should DELETE a slot given the slotId', (done) => {
          let newSlot = new slot({})
          newSlot.save((err, book) => {
                chai.request(server)
                .delete('/slot/' + slot.slotId)
                .end((err, res) => {
                      res.should.have.status(200);
                      res.body.should.be.a('object');
                      res.body.should.have.property('message').eql('Successfully deleted the Slot');
                  done();
                });
          });
      });
  });

  describe('/GET/unusedslots', () => {
    it('it should GET unused slots', (done) => {
        chai.request(server)
        .get('/slot/unusedslots')
        .end((err, res) => {
              res.should.have.status(200);
              res.body.should.be.a('array');
        done();
          });
        });

});
