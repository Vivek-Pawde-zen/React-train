require("dotenv").config();
const express = require("express"); //Import Express
const Joi = require("joi"); //Import Joi
const app = express(); //Create Express Application on the app variable
app.use(express.json()); //used the json file
const bodyParser = require("body-parser");
app.use(bodyParser.json());
const helmet = require("helmet");
app.use(helmet());
var mongoose = require("mongoose");
jsonwebtoken = require("jsonwebtoken");
var cookie = require('cookie-parser')
const cors = require('cors');
app.use(cors());

//const adminSchema1 = require("./schema/admin");
const userRoute = require("./Routes/user");
const slotRoute = require("./Routes/slot");
var dbHost = "mongodb://localhost:27017/PanelManagement";
mongoose.connect(dbHost);

app.use(cookie())

const listener = process.env.PORT | 8080;

app.use("/user", userRoute);
app.use("/slot", slotRoute);

app.listen(listener, () => {
  console.log("Your app is listening on port " + listener);
});




//app.use("/slot", slotRoute);