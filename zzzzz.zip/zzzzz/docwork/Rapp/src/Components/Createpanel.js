import { React, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Drop from './Drop.js';
import "./Assets/createpanel.module.css";
import Authservice from '../services/auth-service.js'
import Dropdown from 'react-dropdown';
import 'react-dropdown/style.css';
import Select from 'react-dropdown-select'
//class Createpanel extends React.Component s
const Createpanel = ({ token }) => {
  //const options=['vivek','pawde'];
  //const defaultOption=options[0];
  //console.log(defaultOption);
const [options, setOptions] = useState( [
    { id: 1, usr: "Vivek" },
    { id: 2, usr: "Raj" }, 
    { id: 3, usr: "Karthick" },
] )
const [options2, setOptions2] = useState( [
  { id: 1, pnl: "panel1" },
  { id: 2, pnl: "panel2" }, 
  { id: 3, pnl: "panel3" },
  { id: 3, pnl: "xpanel4" }
] )
  //const defaultOption=options[0];
  //console.log(defaultValue);
 // const defaultOption2=options2[0];
  //console.log(defaultOption);
  const [panelName, setpanelName] = useState("")
  const [skills, setskills] = useState("")
  const [Interviewer, setInterviewer] = useState("")
  const [panelId,setpanelId] = useState("")
  //console.log(defaultOption);
const [selectedOptions2, setSelectedOptions2] = useState( [ ] )
const [selectedOptions, setSelectedOptions] = useState( [ ] )
  const navigate = useNavigate()
  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await Authservice.createPanel(panelId,panelName, skills, Interviewer).then(
        (data) => {
          console.log(data.token);
          
            navigate("/Panelop")
          
          console.log("created")
          //navigate("/Home")
        },
        (error) => {
          console.log(error)
        }
      );
    } catch (err) {
      console.log(err)
    }
  };

  return (
    <div id='r1'>
      <meta charSet="utf-8" />
      <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
      <title />
      <meta name="description" content />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      {/*<link rel="stylesheet" href="/styles/styles.css" />
              <link rel="stylesheet" href="create-panel.css" />*/}
      <div className="container"style={{width: '80%', marginLeft: '17%'}}>
        <div className="row">
          <div className="min-vh-100 d-flex align-items-center justify-content-center">
            <div className="col-12 col-md-10 col-xl-5 my-5">
              <div className="card">
                <div className="card-body">
                  <h2 className="text-center mb-3">Create a Panel</h2>
                  <form onSubmit={handleCreate}>
                  <div className="form-group mb-3">
                      <label className="form-label"> Panel Id </label>
                      <input type="text" className="form-control" placeholder="Enter panel id" value={panelId} onChange={
                        (e) => setpanelId(e.target.value)} />
                    </div>
                    <div className="form-group mb-3">
                      <label className="form-label"> Panel Name </label>
                      <input type="text" className="form-control" placeholder="Enter panel name" value={panelName} onChange={
                        (e) => setpanelName(e.target.value)} />
                        {/* <Dropdown options={options} onChange={this._onSelect} value={defaultOption} placeholder="Select"/> */}
                    </div>
                    <div style={{width:'400px'}} >
                      {/*<Select options={ options2.map( ( item, index ) => { return { value: item.id, label: item.pnl }} ) } 
                      values={selectedOptions2} onChange={ ( values ) => setSelectedOptions2([...values]) } />*/}
                      <Drop/>
                    </div>

                    <div className="form-group mb-3">
                      <label className="form-label"> Interviewer </label>
                      <input type="text" className="form-control" placeholder="Enter interviewer names" value={Interviewer} onChange={
                        (e) => setInterviewer(e.target.value)} />
                    </div>
                    <div style={{width:'400px'}} >
                      <Select options={ options.map( ( item, index ) => { return { value: item.id, label: item.usr }} ) } 
                      values={selectedOptions} onChange={ ( values ) => setSelectedOptions([...values]) } />
                    </div>
                    <div className="form-group mb-3">
                      <label className="form-label"> Skills </label>
                      <input type="text" className="form-control" placeholder="Java, React etc." value={skills} onChange={
                        (e) => setskills(e.target.value)} />
                    </div>
                    <></>
                    <div className="form-check form-switch mb-3">
                      <input className="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckChecked" defaultChecked />
                      <label className="form-check-label" htmlFor="flexSwitchCheckChecked">Active</label>
                    </div>
                    
                    <div className="d-grid gap-2 d-md-flex justify-content-md-end">
                      <button className="btn btn-warn me-md-2" type="button">Cancel</button>
                      <button className="btn btn-primary" type="submit">Submit</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

}

export default Createpanel;