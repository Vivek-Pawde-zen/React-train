import logo from './logo.svg';
import './App.css';
import {Routes,Route} from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
//import product_table from './Components/product_table.js';
import EditProductFormFunc from './components/edit_product.js';
//import product_form from './Components/product_form.js';
import ProductAppFunc from './components/product_app.js'
function App() {
  return (
    <div className="App">
      <Routes>
        <Route path='/' element={<ProductAppFunc />} exact></Route>
        <Route path='/edit/:id' element={<EditProductFormFunc/>}></Route> 
      </Routes>
    </div>
      
  );
}

export default App;
