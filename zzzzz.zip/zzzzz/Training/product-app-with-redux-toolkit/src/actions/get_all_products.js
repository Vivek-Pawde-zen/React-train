import axios from 'axios';
import { createAsyncThunk } from '@reduxjs/toolkit';

const GetAllProducts =createAsyncThunk(
   'getAllowProducts',
   async (object, {getState,rejectWithValue})=>{

       try {
          const {data} = await axios.get('http://localhost:9090/product');
          console.log("server response:",data);
          return data;
       }
       catch(error){
          console.log('error in get all products',error);
          rejectWithValue(error.respone);
       }
   }


);
export default GetAllProducts;