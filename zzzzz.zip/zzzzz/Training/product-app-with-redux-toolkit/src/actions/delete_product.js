import axios from "axios";
import { createAsyncThunk } from "@reduxjs/toolkit";


 const deleteProduct = createAsyncThunk(
    'deleteProduct',
    async (productId,{ getState, rejectWithValue }) => {
        try {
            const { data } =  await axios.delete(`http://localhost:9090/product/${productId}`,
            productId,
            {
                'Content-type': 'application/json; charset=UTF-8',
                'Access-Control-Allow-Origin': '*'
            }
            );
            console.log("server", data);
            return { productId, data };
        }
        catch (error) {
            console.log('Error in get All Products', error);
            rejectWithValue(error.response);
        }

    }
);


export default  deleteProduct;