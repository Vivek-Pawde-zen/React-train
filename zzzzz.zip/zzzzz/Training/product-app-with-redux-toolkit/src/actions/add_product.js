import axios from "axios";

import { createAsyncThunk } from "@reduxjs/toolkit";

 

const addNewProduct = createAsyncThunk(

    'addNewProduct',

    async (new_product, { getState, rejectWithValue })=> {

        try {

            const {data} = await axios.post(

                'http://localhost:9090/product',

                new_product,

                {

                    'Content-type': 'application/json; charset=UTF-8',

                    'Access-Control-Allow-Origin': '*'

                }              

              );

            console.log('Server response:', data);

            return data;

        }

        catch(error) {

            console.log('Error in Add Product', error);

            rejectWithValue(error.response);

        }

    }

);

 

export default addNewProduct;