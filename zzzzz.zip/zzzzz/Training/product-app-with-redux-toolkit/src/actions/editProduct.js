import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

const editProduct=createAsyncThunk(
    'editProduct',
    async (productid,{getState,rejectWithValue}) => {
        try{
            const {data}=await axios.get(`http://localhost:9090/product/${productid}`);
            console.log('editserver response', data);
            return data;
        }
        catch(error){
            console.log('Error in Get All Products',error);
            rejectWithValue(error.response);
        }
    }
);

export default editProduct;