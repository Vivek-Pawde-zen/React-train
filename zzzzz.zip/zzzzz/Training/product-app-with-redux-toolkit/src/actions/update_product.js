import axios from "axios";

import { createAsyncThunk } from "@reduxjs/toolkit";

const updateProduct = createAsyncThunk(
    'updateProduct',
    async (update_product, { getState, rejectWithValue })=> {
        console.log(update_product);
        try {
            const {data} = await axios.put(
                `http://localhost:9090/product/${update_product.id}`,
                update_product,
                {
                    'Content-type': 'application/json; charset=UTF-8',
                    'Access-Control-Allow-Origin': '*'
                }              
              );
            console.log('update server response:', data);
            return data;

        }
        catch(error) {
            console.log('Error in update Product', error);
            rejectWithValue(error.response);
        }
    }
);

export default updateProduct;