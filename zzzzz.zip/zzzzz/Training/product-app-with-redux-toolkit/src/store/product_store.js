import {configureStore} from "@reduxjs/toolkit";
import productSlice from "../reducers/product_Slice";

const productStore = configureStore({

      reducer: productSlice.reducer
})

export default productStore;