import { createSlice } from "@reduxjs/toolkit";
import GetAllProducts from "../actions/get_all_products";
import deleteProduct from "../actions/delete_product";
import updateProduct from "../actions/update_product";

const productSlice = createSlice({
    name: 'Product App',
    initialState: {
        productList: [],
    },
    reducers: {},
    extraReducers: {
        [GetAllProducts.pending]: (state, action) => {
            state.loading = true;
        },
        [GetAllProducts.fulfilled]: (state, { payload }) => {
            console.log('Reducer payload: ', payload);
            state.loading = false;
            state.productList = payload;
            state.isSuccess = true;
        },
        [GetAllProducts.rejected]: (state, { payload }) => {
            state.loading = false;
            state.isSuccess = false;
            state.message = "failed";
        },
        [deleteProduct.pending]: (state, action) => {
            state.loading = true;
        },
        [deleteProduct.fulfilled]: (state, { payload }) => {
            console.log('Reducer payload: ', payload);
            state.loading = false;
            const {productid,data}=payload;
            state.productList = state.productList.filter(
                (product) => product.id !== productid
              );
            state.isSuccess = true;
        },
        [deleteProduct.rejected]: (state, { payload }) => {
            state.loading = false;
            state.isSuccess = false;
            state.message = "failed";
        },
        [updateProduct.pending]: (state, action) => {
            state.loading = true;
        },
        [updateProduct.fulfilled]: (state, { payload }) => {
            console.log('updated payload: ', payload);
            state.loading = false;
            const updatedProductIndex = state.productList.findIndex(product => product.id === payload.id);
            if (updatedProductIndex !== -1) {
                state.productList[updatedProductIndex] = payload;
              } else {
                state.productList.push(payload);
              }
            state.isSuccess = true;
        },
        [updateProduct.rejected]: (state, { payload }) => {
            state.loading = false;
            state.isSuccess = false;
            state.message = "failed";
        },
    }
});

export default productSlice;