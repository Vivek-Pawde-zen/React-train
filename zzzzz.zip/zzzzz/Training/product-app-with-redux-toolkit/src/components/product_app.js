import ProductFormFunc from './product_form';
import ProductTableFunc from './product_table';
import Badge from 'react-bootstrap/Badge';
        //<div class="col-md-4"><h3><center>Product Application</center></h3></div>

const ProductAppFunc = (props)=>{
    
        return <div class="container">
        <Badge pill bg="dark" style={{fontSize: 36}} >
         Product Application
        </Badge>
        <ProductFormFunc/>
        <br></br>
        <ProductTableFunc/>
        </div>
}

export default ProductAppFunc;
