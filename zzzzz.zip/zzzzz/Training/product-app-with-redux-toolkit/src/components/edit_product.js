import { useEffect, useRef, useState } from 'react';
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import Row from 'react-bootstrap/Row';
import { useDispatch, useSelector } from 'react-redux';
import { Navigate, useNavigate, useParams } from 'react-router-dom';
import updateProduct from '../actions/update_product';
import Badge from 'react-bootstrap/Badge';
 

 const EditProductFormFunc = () => {
 const { id } = useParams();
  const dispatch = useDispatch();
  const form1 = useSelector((state) => state.productList);
  const [form, setForm] = useState(form1.find(element => element.id ==id));

   useEffect(() => {
    setForm(form1.find(element => element.id ==id));
  }, [form1]);

 
  const handleSubmit = () => {
    const update_product = {
      id: form.id,
      name: form.name,
      quantity: form.quantity,
      price: form.price
    };
    dispatch(updateProduct(update_product));
    navigate('/');
  };

    const navigate=useNavigate();
    const idRef = useRef(null);
    const nameRef = useRef(null);
    const quantityRef = useRef(null);
    const priceRef = useRef(null);

  return (
    <div class="container" >
      
      <Badge pill bg="dark" style={{fontSize: 36}} >
           Edit Product
        </Badge>
      <Form>
        <Row className="mb-3">

          <Form.Group as={Col} md="4" controlId="validationName">
            <Form.Label>ID</Form.Label>
            <InputGroup hasValidation>
              <Form.Control
                readOnly
                type="text"
                placeholder="ID"
                value={form.id}
                defaultValue=""
                ref={idRef}
              />
              <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
              <Form.Control.Feedback type="invalid">
              </Form.Control.Feedback>
            </InputGroup>
          </Form.Group>
        </Row>
        <Row className="mb-3">
          <Form.Group as={Col} md="4" controlId="validationName">
            <Form.Label>Name</Form.Label>
            <InputGroup hasValidation>
              <Form.Control
                required
                type="text"
                placeholder="Name"
                value={form.name}
                defaultValue=""
                onChange={(event) => setForm({ ...form, name: event.target.value })}
                // isInvalid={!!errors.name}
                ref={nameRef}
              />
              <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
              <Form.Control.Feedback type="invalid">
                {/* {errors.name} */}
              </Form.Control.Feedback>
            </InputGroup>
          </Form.Group>
        </Row>
        <Row className="mb-3">
          <Form.Group as={Col} md="4" controlId="validationCustomQuantity">
            <Form.Label>Quantity</Form.Label>
            <InputGroup hasValidation>
              <Form.Control
                type="number"
                placeholder="Quantity"
                aria-describedby="inputGroupPrepend"
                required
                value={form.quantity}
                defaultValue=""
                onChange={(event) => setForm({ ...form, quantity: event.target.value })}
                // isInvalid={!!errors.quantity}
                ref={quantityRef}
              />
              <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
              <Form.Control.Feedback type="invalid">
                {/* {errors.quantity} */}
              </Form.Control.Feedback>
            </InputGroup>
          </Form.Group>
        </Row>
        <Row className="mb-3">
          <Form.Group as={Col} md="4" controlId="validationCustomPrice">
            <Form.Label>Price</Form.Label>
            <InputGroup hasValidation>
              <Form.Control
                type="number"
                placeholder="Price"
                aria-describedby="inputGroupPrepend"
                required
                value={form.price}
                defaultValue=""
                onChange={(event) => setForm({ ...form, price: event.target.value })}
                // isInvalid={!!errors.quantity}
                ref={priceRef}
              />
              <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
              <Form.Control.Feedback type="invalid">
                {/* {errors.price} */}
              </Form.Control.Feedback>
           </InputGroup>
          </Form.Group>
        </Row>
        <Button md="1" type="submit" variant="outline-dark" onClick={handleSubmit}>UPDATE</Button>
        <Button md="1"type="submit" variant="outline-dark" onClick={()=>navigate('/')} >CANCEL</Button>
      </Form>
    </div>

  );

};

 export default EditProductFormFunc;


