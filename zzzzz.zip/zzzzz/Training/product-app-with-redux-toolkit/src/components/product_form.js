import {React, useRef, useState} from 'react';
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import Row from 'react-bootstrap/Row';
import Badge from 'react-bootstrap/Badge';
import { useDispatch } from 'react-redux';
import addNewProduct from '../actions/add_product.js';
const ProductFormFunc = (props) => {

    const nameRef = useRef(null);
    const quantityRef = useRef(null);
    const priceRef = useRef(null);

    const [form, setForm] = useState({})
    const [errors, setErrors] = useState({})
    
    const setField = (field, value)=> {
        setForm({...form, [field]:value });
        if(!!errors[field]){
            setErrors({...errors, [field]:null});
        }
    }

    const dispatcher = useDispatch();
    const Createnewproduct=()=>{

      let new_product= {
        name: nameRef.current.value,
        quantity: quantityRef.current.value,
        price: priceRef.current.value
      }
      dispatcher(addNewProduct(new_product));
    }

return (<div class="container">
    <Form data-testid='product-form' >
      <Row className="mb-3">
        <Form.Group as={Col} md="4" controlId="validationName">
          <Form.Label>Name</Form.Label>
          <InputGroup hasValidation>
          <Form.Control
            required
            type="text"
            placeholder="Name"
            value={form.name}
            onChange={(event)=>setField('name', event.target.value)}
            isInvalid={!!errors.name}
            ref={nameRef}
          />
          <Form.Control.Feedback type="invalid">
          {errors.name}
            </Form.Control.Feedback>
            </InputGroup>
        </Form.Group>
       </Row>
        <Row className="mb-3">
        <Form.Group as={Col} md="4" controlId="validationCustomQuantity">
          <Form.Label>Quantity</Form.Label>
          <InputGroup hasValidation>
            <Form.Control
              type="number"
              placeholder="Quantity"
              aria-describedby="inputGroupPrepend"
              required
              value={form.quantity}
              onChange={(event)=>setField('quantity', event.target.value)}
              isInvalid={!!errors.quantity}
              ref={quantityRef}
            />
            <Form.Control.Feedback type="invalid">
              {errors.quantity}
            </Form.Control.Feedback>
          </InputGroup>
        </Form.Group>
        </Row>
        <Row className="mb-3">
        <Form.Group as={Col} md="4" controlId="validationCustomPrice">
          <Form.Label>Price</Form.Label>
          <InputGroup hasValidation>
            <Form.Control
              type="number"
              placeholder="Price"
              aria-describedby="inputGroupPrepend"
              required
              value={form.price}
              onChange={(event)=>setField('price', event.target.value)}
              isInvalid={!!errors.price}
              ref={priceRef}
            />
            <Form.Control.Feedback type="invalid">
            {errors.price}
            </Form.Control.Feedback>
          </InputGroup>
        </Form.Group>
      </Row>
      <Button type="submit"  variant="outline-dark" onClick={Createnewproduct}>ADD PRODUCT</Button>
    </Form>
    </div>
  ); 
}

export default ProductFormFunc;
