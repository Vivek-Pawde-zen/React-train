
import Badge from 'react-bootstrap/Badge';
import {useNavigate } from 'react-router-dom';
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import Pagination from 'react-bootstrap/Pagination';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect } from 'react';
import GetAllProducts from '../actions/get_all_products';
import deleteProduct from '../actions/delete_product';
import editProduct from '../actions/editProduct';

const ProductTableFunc = (props) => { 
    let products = useSelector((state)=>state.productList);
    const navigate=useNavigate();
    let dispatch=useDispatch(); 
    
    useEffect(
        ()=>{
           return ()=>dispatch(GetAllProducts());
        },[]
    )
    const editproduct= (productId)=>{
        const response= dispatch(editProduct(productId));
        navigate(`/edit/${productId}`);
    }
   const  handledelete= (id)=>{
        dispatch(deleteProduct(id));
                                                                                                 window.location.reload(false);
    }


    if(products===undefined)
        products = [];
    console.log('Table products: ', products)
        let productData =  products.map(function(product, index) {
        return (<tr key={index}>
            <td>{product.id}</td>
            <td>{product.name}</td>
            <td>{product.quantity}</td>
            <td>{product.price}</td>
            <td>
            <input type='button' value='EDIT' onClick={()=>editproduct(product.id)}/>
            <input type='button' value='DELETE' onClick={()=>handledelete(product.id)}/>
            
              
            </td>
            </tr>
            );
    })          

    let items = [];

    console.log('items - ', items)
    return <div>
        <Table striped bordered hover variant="dark">
    <thead>
    <tr>
        <th>ID</th>
        <th>NAME</th>
        <th>QUANTITY</th>
        <th>PRICE</th>
        <th>ACTIONS</th>
    </tr>
    </thead>
    <tbody>
    {productData}
    </tbody>
    </Table>
   
    <div>
        <Pagination>{items}</Pagination>
    </div>
    </div>
}

export default ProductTableFunc;
