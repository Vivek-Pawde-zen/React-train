import React, { FunctionComponent } from 'react';

const Hello: FunctionComponent = () => {
  return <div>Hello, World!</div>;
};

export default Hello;