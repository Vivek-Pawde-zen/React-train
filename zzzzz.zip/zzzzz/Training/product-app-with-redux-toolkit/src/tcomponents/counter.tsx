import React, { useState } from 'react';
import  { FunctionComponent } from 'react';

const Counter: FunctionComponent= () => {
    const [Count, setCount] = useState(5);

    const incrementCount = () => {
        setCount(Count + 1);
    }

    return (
        <div>
            <h1>counter: {Count}</h1>
            <br />
            <input type="button" value="increment" onClick={incrementCount} />
        </div>
    );
}

export default Counter;