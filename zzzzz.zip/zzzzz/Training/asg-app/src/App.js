// src/App.js
import React from 'react';
import BeerList from './components/BeerList';

const App = () => {
  return (
    <div className="App">
      <BeerList />
    </div>
  );
};

export default App;