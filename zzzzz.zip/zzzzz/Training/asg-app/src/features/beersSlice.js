import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const fetchBeers = createAsyncThunk(
  'beers/fetchBeers',
  async () => {
    const response = await axios.get('https://api.punkapi.com/v2/beers?page=1&per_page=10');
    return response.data;
  }
);

const beersSlice = createSlice({
  name: 'beers',
  initialState: {
    beers: [],
    status: 'idle',
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchBeers.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchBeers.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.beers = action.payload;
      })
      .addCase(fetchBeers.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      });
  },
});

export default beersSlice.reducer;
export { fetchBeers };