// src/components/BeerList.js
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchBeers } from '../features/beersSlice';

const BeerList = () => {
  const dispatch = useDispatch();
  const { beers, status, error } = useSelector((state) => state.beers);

  useEffect(() => {
    dispatch(fetchBeers());
  }, [dispatch]);

  if (status === 'loading') {
    return <div>Loading...</div>;
  }

  if (status === 'failed') {
    return <div>Error: {error}</div>;
  }

  return (
    <div>
      <h2>Beer List</h2>
      <div className="beer-container">
        {beers.map((beer) => (
          <div key={beer.id} className="beer-card">
            <h3>{beer.name}</h3>
            <p>{beer.description}</p>
            {beer.image_url && (
              <img src={beer.image_url} alt={`Bottle of ${beer.name}`} />
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default BeerList;