import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { RootState, AppDispatch } from '../store/store';
import { fetchBeers } from '../reducers/beersSlice';

interface Beer {
  id: number;
  name: string;
  description: string;
  image_url: string;
}

const BeerList: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { beers, status, error } = useSelector(
    (state: RootState) => state.beers
  );

  useEffect(() => {
    dispatch(fetchBeers());
  }, [dispatch]);

  if (status === 'loading') {
    return <div>Loading...</div>;
  }

  if (status === 'failed') {
    return <div>Error: {error}</div>;
  }

  return (
    <div>
      <h2>Beer List</h2>
      <div className="beer-container">
        {beers.map((beer) => (
          <div key={beer.id} className="beer-card">
            <h3>{beer.name}</h3>
            <p>{beer.description}</p>
            {beer.image_url && (
              <img src={beer.image_url} alt={`Bottle of ${beer.name}`} />
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default BeerList;