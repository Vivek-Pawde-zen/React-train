import React from 'react';
import BeerList from './components/Beerlist';

const App: React.FC = () => {
  return (
    <div className="App">
      <BeerList />
    </div>
  );
};

export default App;