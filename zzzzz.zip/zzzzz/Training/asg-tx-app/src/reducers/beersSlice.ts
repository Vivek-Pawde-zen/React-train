import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';

interface Beer {
  id: number;
  name: string;
  description: string;
  image_url: string;
}

interface BeersState {
  beers: Beer[];
  status: 'idle' | 'loading' | 'failed';
  error: string | null;
}

const initialState: BeersState = {
  beers: [],
  status: 'idle',
  error: null,
};

export const fetchBeers = createAsyncThunk('beers/fetchBeers', async () => {
  const response = await axios.get<Beer[]>(
    'https://api.punkapi.com/v2/beers'
  );
  return response.data;
});

const beersSlice = createSlice({
  name: 'beers',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchBeers.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchBeers.fulfilled, (state, action) => {
        state.status = 'idle';
        state.error = null;
        state.beers = action.payload;
      })
      .addCase(fetchBeers.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message ?? 'Something went wrong.';
      });
  },
});

export default beersSlice.reducer;