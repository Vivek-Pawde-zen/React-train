
import React from 'react'; 
import ReactDOM from 'react-dom';

const Welcome=(props)=>{
    return <div>
    <h1>Welocme to react by {props.company} count: {props.count}</h1>
    </div>
    
}
export default Welcome;//      {editingProduct ? (
    //<EditProductForm product={editingProduct} updateProduct={updateProduct}cancelEdit={cancelEdit}/>
 // ) : null}