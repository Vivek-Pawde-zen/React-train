import { useContext } from "react";
import Appcontext from "../context/app_context";
const Counter = (props) => {
    const [count,setCount]=useContext(Appcontext);


    
    const incrementCount=()=>{
        setCount(count+1);
    }
    return <div>


        <h1>Count = {count}</h1>

        <br></br>

        <input type="button" value="INCREMENT" onClick={incrementCount}></input>

    </div>

}

 

export default Counter;