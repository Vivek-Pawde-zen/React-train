const Welcome_Func = (props)=> {

    return <div data-testid='welcomedivid' foo='aaa'>

            <h1>Welcome to React by {props.company} - fname: {props.fname}</h1>

            <br></br>

            <button value="OK" disabled>OK</button>

        </div>

}

 

export {Welcome_Func};