import {Link} from 'react-router-dom';
export const Header=()=>

{
     return <div>
        <nav>
            <ul>

                <Link to="/aboutus">
                <li> About Us</li >
                </Link>
                <Link to="/contactus">
                <li> Contact us</li >
                </Link>
                <Link to="/">
                <li> Homepage</li >
                </Link>
            </ul>
        </nav>
     </div>



}