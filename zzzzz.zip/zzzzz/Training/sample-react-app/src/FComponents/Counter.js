import React,{useState}from 'react'; 
import ReactDOM from 'react-dom';

const Counter=(props)=>{
    const[Count,setCount]=useState(5);
    const incrementCount=()=>{
         setCount(Count+1);
    }
    return <div>
    <h1>counter: {Count}</h1>
    <br></br>
    <input type="button" value="increment" onClick={incrementCount}></input>
    </div>
    
}
export default Counter;