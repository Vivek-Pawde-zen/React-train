import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import CartContext from '../context/Cartcontext.js';
const Book = () => {
  const { selectedComputerBook, setSelectedMathBook } = useContext(CartContext);
  const navigate = useNavigate();

  const handleSelection = (book) => {
    setSelectedMathBook(book);
    navigate('/cart');
  };

  return (
    <div data-testid='Bookid'>
      <h1>Select a Math Book</h1>
      <button onClick={() => handleSelection('Algebra')}>Algebra</button>
      <td></td>
      <button onClick={() => handleSelection('Geometry')}>Geometry</button>

    </div>
  );
};

export default Book;