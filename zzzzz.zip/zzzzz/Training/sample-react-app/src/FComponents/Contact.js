import {useParams} from 'react-router-dom';
import QueryString from 'query-string';
export const Contact =()=>{
    let {city}= useParams();
    return<div>
        <h1>Contact us Page-{city}</h1>
    </div>
}