/*

function ProductTable({ products, deleteProduct, editProduct }) {
  return (
    <div>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => (
            <tr key={product.id}>
              <td>{product.name}</td>
              <td>{product.quantity}</td>
              <td>{product.price}</td>
              <td>
                <button onClick={() => editProduct(product)}>Edit</button>
                <button onClick={() => deleteProduct(product.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}*/
import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { deleteProduct } from "../actions/product_action.js";
import EditProductForm from './EditProductForm';
import {  useNavigate } from "react-router-dom";
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
const ProductTable = () => {
  const products = useSelector((state) => state.products);
  const dispatch = useDispatch();
  const navigate= useNavigate();
  const handleDeleteProduct = (productId) => {
    dispatch(deleteProduct(productId));
  };
//   const goTo=()=>{
    
//     navigate('/edit');
// }

  return (
    <Table striped bordered hover variant="dark">
      <thead>
        <tr>
          <th>Name</th>
          <th>Quantity</th>
          <th>Price</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        {products.map((product,index) => (
          <tr key={product.id}>
            <td>{product.name}</td>
            <td>{product.quantity}</td>
            <td>{product.price}</td>
            <td>
              
              <Button variant="outline-secondary" size="sm" onClick={()=>navigate(`/edit/${index}`)}>Edit</Button>
              <Button variant="outline-secondary" size="sm" onClick={() => handleDeleteProduct(product.id)}>Delete</Button>
              
               
              
            </td>
          </tr>
        ))}
      </tbody>
    </Table>
  );
};

export default ProductTable;//<input type='button'value='Edit' onClick={goTo} ></input>
//<EditProductForm product={product} />
