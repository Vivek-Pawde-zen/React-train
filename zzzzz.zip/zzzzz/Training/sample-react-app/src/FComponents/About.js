import { useLocation, useNavigate } from "react-router-dom";

import QueryString from "query-string";



export const About =(props)=>{
    let location = useLocation();

    const allParams = QueryString.parse(location.search);
    const country=allParams.country;
    const state=allParams.state;

    const navigate= useNavigate();

    const goTo=()=>{

        navigate('/');
    }
    return<div>
        <h1>About us Page - {state}{country}</h1>
        <input type='button'value='Go to home' onClick={goTo} ></input>
    </div>
}