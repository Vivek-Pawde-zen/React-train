/*import React, { useState } from 'react';
import ProductForm from './ProductForm';
import ProductTable from './ProductTable';
//import EditProductForm from './EditProductForm';

function ProductApp() {
  const [products, setProducts] = useState([
    { id: 1, name: 'Table', quantity: 25, price: 2000 },
    { id: 2, name: 'Chairs', quantity: 100, price: 800 },
  ]);

  const [editingProduct, setEditingProduct] = useState(null);

  const addProduct = (newProduct) => {
    setProducts([...products, newProduct]);
  };

  const deleteProduct = (productId) => {
    setProducts(products.filter((product) => product.id !== productId));
  };

  const editProduct = (product) => {
    setEditingProduct(product);
  };

  const updateProduct = (updatedProduct) => {
    setProducts(products.map((product) => (product.id === updatedProduct.id ? updatedProduct : product)));
    setEditingProduct(null);
  };

  const cancelEdit = () => {
    setEditingProduct(null);
  };

  return (
    <div>
      <h1>                      Product Application         </h1>
      <ProductForm addProduct={addProduct} />

      <ProductTable products={products} deleteProduct={deleteProduct} editProduct={editProduct} />
    </div>
  );
}*/
import Pagination from 'react-bootstrap/Pagination';

import React from 'react';
import ProductForm from './ProductForm';
import ProductTable from './ProductTable';
import { Provider } from 'react-redux';
import Badge from 'react-bootstrap/Badge';
import Button from 'react-bootstrap/Button';

//import 
//const s
import { Product_Store } from '../store/Product_Store';
const ProductApp = () => {
  return (
    //<Provider store={Product_Store}>
      <div>
      
      <Badge pill bg="dark" style={{fontSize: 36}} >
         Product Application
      </Badge>
      <br></br>
      <br></br>
      <br></br>
      <ProductForm />
      <ProductTable />
      <Pagination>
      <Pagination.First />
      <Pagination.Prev />
      <Pagination.Item></Pagination.Item>
      <Pagination.Ellipsis />

      <Pagination.Item>{10}</Pagination.Item>
      <Pagination.Item>{11}</Pagination.Item>
      <Pagination.Item active></Pagination.Item>
      <Pagination.Item>{13}</Pagination.Item>
      <Pagination.Item disabled>{14}</Pagination.Item>

      <Pagination.Ellipsis />
      <Pagination.Item>{20}</Pagination.Item>
      <Pagination.Next />
      <Pagination.Last />
    </Pagination>
      </div>
    //</Provider>
  );
};

export default ProductApp;