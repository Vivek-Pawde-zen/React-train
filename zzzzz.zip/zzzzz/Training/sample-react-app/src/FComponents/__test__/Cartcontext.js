import React, { createContext, useState } from 'react';

const CartContext = createContext();



export const BookProvider  = ({ children }) => {
  const [selectedComputerBook, setSelectedComputerBook] = useState('');
  const [selectedMathBook, setSelectedMathBook] = useState('');

  return (
    <CartContext.Provider
      value={{
        selectedComputerBook,
        setSelectedComputerBook,
        selectedMathBook,
        setSelectedMathBook,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};
export default CartContext ;