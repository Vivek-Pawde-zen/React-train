import {screen,render,cleanup} from "@testing-library/react";
import Cart from '../Cart.js';
import  CartContext from '../../context/Cartcontext.js';
import { BrowserRouter } from 'react-router-dom'; 

test('Render Cart Component',()=>{

    render(
        <BrowserRouter>
       <CartContext.Provider value={{selectedComputerBook:[],setSelectedComputerBook:jest.fn(),selectedMathBook:[],setSelectedMathBook :jest.fn()}} >
 
           <Cart/>
      </CartContext.Provider>  
      </BrowserRouter>

    );
    let Welcomedivcomp= screen.getByTestId('Cartid');
    expect(Welcomedivcomp).toBeInTheDocument(); 
})

test('check specific texts inside component',()=>{

    render(
        <BrowserRouter>
       <CartContext.Provider value={{selectedComputerBook:[],setSelectedComputerBook:jest.fn(),selectedMathBook:[],setSelectedMathBook :jest.fn()}} >
  
            <Cart/>
       </CartContext.Provider>  
       </BrowserRouter>
 
     );
    let Welcomedivcomp= screen.getByTestId('Cartid');
    expect(Welcomedivcomp).toHaveTextContent('Shopping Cart Page'); 

})

test('check specific tags inside component',()=>{

    render(
        <BrowserRouter>
       <CartContext.Provider value={{selectedComputerBook:[],setSelectedComputerBook:jest.fn(),selectedMathBook:[],setSelectedMathBook :jest.fn()}} >
  
            <Cart/>
       </CartContext.Provider>  
       </BrowserRouter>
 
     );
    let Welcomedivcomp= screen.getByTestId('Cartid');
    expect(Welcomedivcomp).toContainHTML("h1"); 

})



