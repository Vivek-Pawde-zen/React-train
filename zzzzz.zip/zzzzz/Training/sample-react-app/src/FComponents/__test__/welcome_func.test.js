import {screen,render,cleanup} from "@testing-library/react";
import {Welcome_Func} from '../welcome_func.js';


test('RenderWelocme Component',()=>{

    render(<Welcome_Func/>);
    let Welcomedivcomp= screen.getByTestId('welcomedivid');
    expect(Welcomedivcomp).toBeInTheDocument(); 
})

test('check specific texts inside component',()=>{

    render(<Welcome_Func/>);
    let Welcomedivcomp= screen.getByTestId('welcomedivid');
    expect(Welcomedivcomp).toHaveTextContent('Welcome to React by - fname: OK'); 

})

test('check specific tags inside component',()=>{

    render(<Welcome_Func/>);
    let Welcomedivcomp= screen.getByTestId('welcomedivid');
    expect(Welcomedivcomp).toContainHTML("h1"); 

})

test('Button is disabled',()=>{

    render(<Welcome_Func/>);
    expect(screen.getByRole('button',{name:'OK'})).toBeDisabled(); 

})

test('check specific attribute inside component',()=>{

    render(<Welcome_Func/>);
    let Welcomedivcomp= screen.getByTestId('welcomedivid');
    expect(Welcomedivcomp.hasAttribute('foo')).toBeTruthy(); 

})