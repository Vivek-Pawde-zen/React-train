import {screen,render,cleanup} from "@testing-library/react";
import Book from '../Book.js';
import  CartContext from '../../context/Cartcontext.js';
import { BrowserRouter } from 'react-router-dom'; 

test('RenderBook Component',()=>{

    render(
        <BrowserRouter>
       <CartContext.Provider value={{selectedComputerBook:{},setSelectedComputerBook:jest.fn(),selectedMathBook:{},setSelectedMathBook :{}}} >
       
           <Book/>
      </CartContext.Provider>  
      </BrowserRouter>

    );
    let Welcomedivcomp= screen.getByTestId('Bookid');
    expect(Welcomedivcomp).toBeInTheDocument(); 
})

test('check specific texts inside component',()=>{

    render(
        <BrowserRouter>
       <CartContext.Provider value={{selectedComputerBook:[],setSelectedComputerBook:jest.fn(),selectedMathBook:[],setSelectedMathBook :{}}} >
  
            <Book/>
       </CartContext.Provider>  
       </BrowserRouter>
 
     );
    let Welcomedivcomp= screen.getByTestId('Bookid');
    expect(Welcomedivcomp).toHaveTextContent('Select a Math Book'); 

})

test('check specific tags inside component',()=>{

    render(
        <BrowserRouter>
       <CartContext.Provider value={{selectedComputerBook:[],setSelectedComputerBook:jest.fn(),selectedMathBook:[],setSelectedMathBook :{}}} >
  
            <Book/>
       </CartContext.Provider>  
       </BrowserRouter>
 
     );
    let Welcomedivcomp= screen.getByTestId('Bookid');
    expect(Welcomedivcomp).toContainHTML("h1"); 

})


test('Check Algebra Button ',()=>{

    render(
        <BrowserRouter>
       <CartContext.Provider value={{selectedComputerBook:{},setSelectedComputerBook:jest.fn(),selectedMathBook:{},setSelectedMathBook :{}}} >
  
            <Book/>
       </CartContext.Provider>  
       </BrowserRouter>
 
     );
    expect(screen.getByRole('button',{name:'Algebra'})).toBeEnabled(); 

})

test('Check Geometry Button ',()=>{

    render(
        <BrowserRouter>
       <CartContext.Provider value={{selectedComputerBook:{},setSelectedComputerBook:jest.fn(),selectedMathBook:{},setSelectedMathBook :{}}} >
  
            <Book/>
       </CartContext.Provider>  
       </BrowserRouter>
 
     );
    expect(screen.getByRole('button',{name:'Geometry'})).toBeEnabled(); 

})

