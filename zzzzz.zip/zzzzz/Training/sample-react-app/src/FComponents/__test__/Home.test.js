import {screen,render,cleanup} from "@testing-library/react";
import Home from '../Home.js';
import  CartContext from '../../context/Cartcontext.js';
import { BrowserRouter } from 'react-router-dom'; 

test('Renderhome Component',()=>{

    render(
        <BrowserRouter>
       <CartContext.Provider value={{selectedComputerBook:{},setSelectedComputerBook:jest.fn(),selectedMathBook:{},setSelectedMathBook :{}}} >
 
           <Home/>
      </CartContext.Provider>  
      </BrowserRouter>

    );
    let Welcomedivcomp= screen.getByTestId('homeid');
    expect(Welcomedivcomp).toBeInTheDocument(); 
})

test('check specific texts inside component',()=>{

    render(
        <BrowserRouter>
       <CartContext.Provider value={{selectedComputerBook:{},setSelectedComputerBook:jest.fn(),selectedMathBook:{},setSelectedMathBook :{}}} >
  
            <Home/>
       </CartContext.Provider>  
       </BrowserRouter>
 
     );
    let Welcomedivcomp= screen.getByTestId('homeid');
    expect(Welcomedivcomp).toHaveTextContent('Select a Computer Book'); 

})

test('check specific tags inside component',()=>{

    render(
        <BrowserRouter>
       <CartContext.Provider value={{selectedComputerBook:{},setSelectedComputerBook:jest.fn(),selectedMathBook:{},setSelectedMathBook :{}}} >
  
            <Home/>
       </CartContext.Provider>  
       </BrowserRouter>
 
     );
    let Welcomedivcomp= screen.getByTestId('homeid');
    expect(Welcomedivcomp).toContainHTML("h1"); 

})

test('Check CoreJava Button ',()=>{

    render(
        <BrowserRouter>
       <CartContext.Provider value={{selectedComputerBook:{},setSelectedComputerBook:jest.fn(),selectedMathBook:{},setSelectedMathBook :{}}} >
  
            <Home/>
       </CartContext.Provider>  
       </BrowserRouter>
 
     );
    expect(screen.getByRole('button',{name:'CoreJava'})).toBeEnabled(); 

})

test('Check Python Button ',()=>{

    render(
        <BrowserRouter>
       <CartContext.Provider value={{selectedComputerBook:{},setSelectedComputerBook:jest.fn(),selectedMathBook:{},setSelectedMathBook :{}}} >
  
            <Home/>
       </CartContext.Provider>  
       </BrowserRouter>
 
     );
    expect(screen.getByRole('button',{name:'Python'})).toBeEnabled(); 

})

test('Check Angular Button ',()=>{

    render(
        <BrowserRouter>
       <CartContext.Provider value={{selectedComputerBook:{},setSelectedComputerBook:jest.fn(),selectedMathBook:{},setSelectedMathBook :{}}} >
  
            <Home/>
       </CartContext.Provider>  
       </BrowserRouter>
 
     );
    expect(screen.getByRole('button',{name:'Angular'})).toBeEnabled(); 

})




