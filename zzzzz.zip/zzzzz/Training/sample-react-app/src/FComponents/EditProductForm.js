/*import React, { useState } from 'react';
function EditProductForm({ product, updateProduct, cancelEdit }) {
  const [editedProduct, setEditedProduct] = useState(product);
  return (
    <div>
      <h2>Edit Product</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="name" value={editedProduct.name} onChange={handleChange} required/>
        <br></br>
        <input type="number" name="quantity" value={editedProduct.quantity}  onChange={handleChange} required />
        <br></br>
        <input type="number"  name="price" value={editedProduct.price} onChange={handleChange} required />
        <br></br>
        <button type="submit">Update</button>
        <button onClick={cancelEdit}>Cancel</button>
      </form>
    </div>
  );
  }*/
  import React, { useState } from 'react';
  import { useDispatch , useSelector} from 'react-redux';
  import { updateProduct } from "../actions/product_action.js";
  import { useParams } from 'react-router-dom';
  import { useNavigate } from 'react-router-dom';
  import Button from 'react-bootstrap/Button';
  import Badge from 'react-bootstrap/Badge';
  const EditProductForm = () => {
    const {index}=useParams();
   const product = useSelector((state) => state.products)[index];
   console.log(product);
   
   const navigate=useNavigate();
    const [editedProduct, setEditedProduct] = useState(product);
    const dispatch = useDispatch();
  
    const handleUpdateProduct = (e) => {

      dispatch(updateProduct(editedProduct));
      navigate('/');
    };
  
    return (
      
      <div>
      <Badge pill bg="dark" style={{fontSize: 26}} >
         Edit product
      </Badge>
      <br></br>
      <br></br>
        <input
          type="text"
          value={editedProduct.name}
          onChange={(e) => setEditedProduct({ ...editedProduct, name: e.target.value })}
        />
        <br></br>
        <input
          type="number"
          value={editedProduct.quantity}
          onChange={(e) => setEditedProduct({ ...editedProduct, quantity: e.target.value })}
        />
        <br></br>
        <input
          type="number"
          value={editedProduct.price}
          onChange={(e) => setEditedProduct({ ...editedProduct, price: e.target.value })}
        />
        <br></br>
        <br></br>
        <Button variant="outline-dark" size="sm" onClick={handleUpdateProduct}>UPDATE</Button>
        <Button variant="outline-dark" size="sm" onClick={()=>navigate('/')}>CANCEL</Button>
      </div>
    );
  };
  

export default EditProductForm;