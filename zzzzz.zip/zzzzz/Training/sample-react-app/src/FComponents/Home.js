import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import  CartContext from '../context/Cartcontext.js';

const Home = () => {
  const { setSelectedComputerBook } = useContext(CartContext);
  const navigate = useNavigate();

  const handlechoice = (book) => {
    setSelectedComputerBook(book);
    navigate('/book');
  };

  return (
    <div data-testid='homeid'>
      <h1>Select a Computer Book</h1>
      <button onClick={() => handlechoice('Java')}>CoreJava</button>
      <td></td>
      <button onClick={() => handlechoice('Python')}>Python</button>
      <td></td>
      <button onClick={() => handlechoice('Angular')}>Angular</button>
      <td></td>
    </div>
  );
};

export default Home;