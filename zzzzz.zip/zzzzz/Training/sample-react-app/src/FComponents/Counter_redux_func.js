import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { incrementAction } from "../actions/increment_action";

const Counter_Redux_Func = (props)=> {

    const dispatcher = useDispatch();
    let count = useSelector((state)=>state);
    const incrementCount = ()=> { //Closure function
        dispatcher(incrementAction(count));
    }
    
    return <div>
            <h1>Counter = {count}</h1>
            <br></br>
            <input type="button" value="INCREMENT" onClick={incrementCount}></input>
        </div>
}

export {Counter_Redux_Func};