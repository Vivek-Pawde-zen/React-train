

/*function ProductForm({ addProduct }) {
  const [name, setName] = useState('');
  const [quantity, setQuantity] = useState('');
  const [price, setPrice] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const newProduct = {
      id: Math.random(), 
      name,
      quantity: parseInt(quantity),
      price: parseFloat(price),
    };
    addProduct(newProduct);
    setName('');
    setQuantity('');
    setPrice('');
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} required/>
        <br></br><br></br>
        <input
          type="number"
          placeholder="Quantity"
          value={quantity}
          onChange={(e) => setQuantity(e.target.value)}
          required
        />
        <br></br><br></br>
        <input
          type="number"
          placeholder="Price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
          required
        />
        <br></br>
        <button type="submit">ADD PRODUCT</button>
        <br></br>
      </form>
    </div>
  );
}*/


import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addProduct } from "../actions/product_action.js";
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';

const ProductForm = () => {
  const [name, setName] = useState('');
  const [quantity, setQuantity] = useState('');
  const [price, setPrice] = useState('');

  const dispatch = useDispatch();

  const handleAddProduct = () => {
    if (name && quantity && price) 
    {
      dispatch(addProduct({ name, quantity, price }));
      setName('');
      setQuantity('');
      setPrice('');
    }
  };

  return (
    <div>
      <Form variant="dark">
      <Form.Group className="mb-3" variant="dark">
      <input
        type="text"
        placeholder="Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <br></br>
      <input
        type="number"
        placeholder="Quantity"
        value={quantity}
        onChange={(e) => setQuantity(e.target.value)}
      />
      <br></br>
      <input
        type="number"
        placeholder="Price"
        value={price}
        onChange={(e) => setPrice(e.target.value)}
      />
      </Form.Group>
      </Form>
     

      <Button variant="outline-dark"onClick={handleAddProduct}>
         ADD PRODUCT
      </Button>
      <br></br>
      <br></br>
      <br></br>
      <br></br>

    </div>
  );
};


export default ProductForm;