
import React,{useEffect, useState}from 'react'; 
import ReactDOM from 'react-dom';

const Clock=(props)=>{
    const[currentTime,setcurrentTime]=useState(new Date().toLocaleString());
    //const incrementCount=()=>{
     //    setCount(Count+1);
    //}
    useEffect
    (
       ()=>{
            console.log('Useeffect called');
            setInterval(
              ()=>setcurrentTime(new Date().toLocaleString()),
              1000
            );
          },
          []
    );
  
    return <div>
       <h1>{currentTime} </h1>
    
    </div>
    
}
export default Clock;