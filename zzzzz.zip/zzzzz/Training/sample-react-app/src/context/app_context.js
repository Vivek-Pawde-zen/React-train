import { createContext } from "react";
const Appcontext=createContext();

export default Appcontext;