import React, { createContext, useState } from 'react';

const CartContext = createContext();
export default CartContext;
