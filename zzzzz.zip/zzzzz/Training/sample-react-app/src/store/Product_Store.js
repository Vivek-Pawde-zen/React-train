import Product_reducer from '../reducers/Product_reducer';
import { legacy_createStore } from "redux";

const Product_Store = legacy_createStore(Product_reducer);
export {Product_Store}