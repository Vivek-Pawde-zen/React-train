import { countReducer } from "../reducers/Count_reducer";
import { legacy_createStore } from "redux";

const countStore = legacy_createStore(countReducer);

export {countStore}
