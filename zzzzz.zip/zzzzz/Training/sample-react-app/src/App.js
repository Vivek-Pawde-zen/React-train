import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
//import { Provider } from 'react-redux';
//import { Product_Store } from './store/Product_Store';
//import {Buttons} from './Components/Button';
//import Counter from './FComponents/Counter.js';
import './App.css';
//import { Welcome } from './components/welcome';
//import { Counter } from './components/counter';
//import {Clock} from './components/clock';
//import { Parent } from './components/parent';
//import { Welcome_Func } from './func_components/welcome_func';
//import { Counter_Func } from './func_components/counter_func';
//import { Clock_Func } from './func_components/clock_func';
//import { Counter_Redux_Func } from './FComponents/Counter_redux_func.js';
//import {Header} from './FComponents/Header.js';
import {Routes,Route} from 'react-router-dom';
//import {Homepage} from './FComponents/Homepage.js';
import Cart from './FComponents/Cart.js';
import Book from './FComponents/Book.js';
import Home from './FComponents/Home.js';
import Cartcontext from './context/Cartcontext.js';
//import {Welcome_Func} from './FComponents/welcome_func.js';

import { useState } from 'react';


function App() {
  const [selectedComputerBook, setSelectedComputerBook] = useState({});
  const [selectedMathBook, setSelectedMathBook] = useState({});  

  return (
    <div className="App">

        <Cartcontext.Provider value={{selectedComputerBook,setSelectedComputerBook,selectedMathBook,setSelectedMathBook,}} >
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/book" element={<Book/>} />
          <Route path="/cart" element={<Cart />} />
        </Routes>
        </Cartcontext.Provider>  

    </div>
  );
       
  
  
  //<Counter count='5'/>      <Routes>
        //<Route path='/' element={<ProductApp />} exact></Route>
        //<Route path='/edit/:index' element={<EditProductForm  />} ></Route>
        //    
        //<Counter/>
        //</Appcontext.Provider>  
        
      //</Routes>
     //<Counter_Redux_Func />
     //<Counter count={3}/>ProductApp />    <div className="App">
      /*<Header />
      <Routes>
        <Route path='/' element={<Homepage/>} exact></Route>
        <Route path='/aboutus' element={<About/>} ></Route>
        <Route path='/contactus/:city' element={<Contact/>} ></Route>
        <Route path='*' element={<div><h1>ERRor 404 page not found </h1></div>}> </Route>
      </Routes>
    </div>*/  /**/
/*

*/

}

export default App;
