const incrementAction = (state) => {
    return {
      type: 'INCREMENT',
      payload: state + 1
    }
  }

export {incrementAction}
