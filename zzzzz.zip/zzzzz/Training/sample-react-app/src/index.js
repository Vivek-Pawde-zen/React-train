import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { BrowserRouter } from 'react-router-dom'; 
//import { countStore } from './store/Count_store';
import { Provider } from 'react-redux';
import { Product_Store } from './store/Product_Store';
/*
let initialCount = 0;
const countReducer = (state=initialCount, action)=> {
  switch(action.type) {
    case 'INCREMENT': return action.payload
    case 'DECREMENT': return action.payload
    default: return state
  }
}

const countStore = legacy_createStore(countReducer);

const incrementAction = (state) => {
  return {
    type: 'INCREMENT',
    payload: state + 1
  }
}
const decrementAction = (state) => {
  return {
    type: 'DECREMENT',
    payload: state - 1
  }
}

countStore.subscribe( //optional step
    ()=>console.log('STATE: ', countStore.getState())
  );

  countStore.dispatch(incrementAction(0));
  countStore.dispatch(incrementAction(countStore.getState()));
  countStore.dispatch(incrementAction(countStore.getState()));
  countStore.dispatch(incrementAction(countStore.getState()));

  countStore.dispatch(decrementAction(countStore.getState()));
  countStore.dispatch(decrementAction(countStore.getState()));
  countStore.dispatch(decrementAction(countStore.getState()));
  countStore.dispatch(decrementAction(countStore.getState()));
    <React.StrictMode>
    /*<Provider store={countStore}>
      <App />
    </Provider>
*/
import Cartcontext from './context/Cartcontext.js';
const root = ReactDOM.createRoot(document.getElementById('root'));
 
root.render(
  <React.StrictMode>

    <BrowserRouter>
    
      <App />
      
    </BrowserRouter>

  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();