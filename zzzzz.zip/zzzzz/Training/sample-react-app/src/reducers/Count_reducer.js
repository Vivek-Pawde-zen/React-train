let initialCount = 0;
const countReducer = (state=initialCount, action)=> {
  switch(action.type) {
    case 'INCREMENT': return action.payload
    case 'DECREMENT': return action.payload
    default: return state
  }
}

export {countReducer};
