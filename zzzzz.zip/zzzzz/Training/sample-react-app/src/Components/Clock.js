import  React  from 'react';

export class Clock extends React.Component {

constructor(props){
    super(props);
    this.state={currentTime:new Date().toLocaleString()};

    //setInterval(arrowFunc,duration);
    //setInterval(()=>this.setState)
}
  render() 
  {
    return <div>
        <h1>{this.state.currentTime} </h1>
        
        </div>
  }
  componentDidMount(){
    console.log("Component did mount called");
    setInterval(
        ()=>this.setState({currentTime: new Date().toLocaleString()}),
        1000
    );
  }
}
