import  React  from 'react';
import PropTypes from 'prop-types';

//import render from 




export class Welcome extends React.Component {
  render() {
    return <div><h1>Welocme to react by {this.props.company} count: {this.props.cnt}fname: {this.props.fname}</h1></div>
  }
}
//export  Welcome;
Welcome.propTypes = {
  company: PropTypes.string,
  cnt: PropTypes.string,
  fname:function(props,propName,ComponentName){
    if(props[propName].length<3){return Error('min 3 char required')}
  }
};