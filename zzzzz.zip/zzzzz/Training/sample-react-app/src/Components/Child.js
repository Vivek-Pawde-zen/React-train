import  React  from 'react';

//import render from 




export class Child extends React.Component {
    callParentIncrementFunction(){
        this.props.incrementFunc();
    }
  render() {
    return <div>
           <h1>"Child component"</h1>
           <input type="button" value="INCREMENT" onClick={this.callParentIncrementFunction.bind(this)}></input>
           </div>
  }
}
