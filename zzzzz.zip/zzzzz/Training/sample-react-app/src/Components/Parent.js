import  React  from 'react';
import {Child} from './Child';
//import render from 




export class Parent extends React.Component {
  constructor(props){
    super(props);
    this.state={x:20}
  }
  incrementX(){
        this.setState({x:this.state.x=1});
  }
  render() {
    return<div>
     <h1>Parent Component: x={this.state.x}</h1>
     <br></br>
     <br></br>   
     <Child count={5} incrementFunc={this.incrementX.bind(this)}/>
     </div>
  }
}
