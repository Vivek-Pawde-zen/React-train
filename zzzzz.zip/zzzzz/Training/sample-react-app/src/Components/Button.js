import React from 'react'
export class Buttons extends React.component{
  render(){
         return<div>
              <button onClick={alert('OK clicked')}>OK</button>
              <button onClick={alert('Cancel clicked')}>CANCEL</button>
                 
            </div>  
           
      }
}