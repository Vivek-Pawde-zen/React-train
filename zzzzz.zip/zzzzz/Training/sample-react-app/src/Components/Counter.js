import  React  from 'react';

//import render from 




export class Counter extends React.Component {

  constructor(props){
    super(props);
    this.state={count:5}
  }
  incrementClick(){
    console.log("Increment function called");
    this.setState({count:this.state.count+1})
  }

  render() 
  {
    return <div>
        <h1>Count is {this.props.count} </h1>
        <input type='button' value="increment" onClick={this.incrementClick.bind(this)}></input>
        </div>
  }
}
