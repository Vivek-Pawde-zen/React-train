const express = require("express"); //import express
const router = express.Router();
const panel = require("./../Controller/panel");
const verify = require("./../Middleware/auth");


router.get("/getPanel", panel.getPanel);
router.get("/:skills", verify.verifyToken, panel.getPanelBySkills);
router.post("/", verify.verifyToken, panel.createPanel);
router.put("/:panelId", verify.verifyToken, panel.updatePanel);
router.delete("/:panelId", verify.verifyToken, panel.deletePanel);



module.exports = router; // export to use in server.js
