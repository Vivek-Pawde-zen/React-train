const express = require("express"); //import express
const router = express.Router();
const slot = require("./../Controller/slot");
const verify = require("./../Middleware/auth.js");

router.get("/getSlot", verify.verifyToken, slot.getSlot);
router.post("/createSlot", verify.verifyToken, slot.createSlot);
router.put("/:slotId", verify.verifyToken, slot.updateSlot);
router.delete("/:slotId", verify.verifyToken, slot.deleteSlot);
router.get("/unusedslots", verify.verifyToken, slot.getUnusedSlot);
router.get("/highestslot", verify.verifyToken, slot.getHighestSlot);



module.exports = router; // export to use in server.js
