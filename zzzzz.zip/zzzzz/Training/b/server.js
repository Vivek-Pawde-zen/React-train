require("dotenv").config();
const express = require("express"); //Import Express
//const Joi = require("joi"); //Import Joi
const app = express(); //Create Express Application on the app variable
app.use(express.json()); //used the json file
const bodyParser = require("body-parser");
app.use(bodyParser.json());
const helmet = require("helmet");
app.use(helmet());
var mongoose = require("mongoose");
jsonwebtoken = require("jsonwebtoken");

const panelSchema1 = require("./schema/panelSchema");
const slotSchema1 = require("./schema/slotSchema");
const adminSchema1 = require("./schema/admin");

var dbHost = "mongodb://localhost:27017/PanelManagement";
mongoose.connect(dbHost);

// const routes = require('./routes'); // import the routes
const panelRoute = require("./Routes/panel");
const slotRoute = require("./Routes/slot");
const userRoute = require("./Routes/user");

app.use("/panel", panelRoute); //to use the routes
app.use("/slot", slotRoute);
app.use("/", userRoute);

const listener = app.listen(process.env.PORT || 3000, () => {
  console.log("Your app is listening on port " + listener.address().port);
});

module.exports = app;
