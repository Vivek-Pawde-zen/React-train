require("dotenv").config();

const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
//const auth = require("./../Middleware/auth");
const postUser = require("./../schema/userSchema");
//onst user = require("../task.js");


const register = async (req, res) => {
    try {
        // Get user input
        const { username, password, firstname, lastname, email, phone } = req.body;

        // Validate user input
        if (!(username && email && password && firstname && lastname && phone)) {
            res.status(400).send("All input fields are required");
        }



        //Encrypt user password
        encryptedPassword = await bcrypt.hash(password, 10);

        // Create user in our database
        const user = await postUser.create({
            //
            username,
            password: encryptedPassword,
            firstname,
            lastname,
            email,
            phone,
        });

        // Create token
        const token1 = jwt.sign(
            { user_id: user._id, username },
            process.env.TOKEN_KEY,
            {
                expiresIn: "9h",
            }
        );
        // save user token
        user.token = token1;

        // return new user
        res.status(201).json(user);
        console.log("User registered Successfully");
    } catch (err) {
        console.log(err);
    }
}; // Our route 3 registeration  ends here

///route 1: log in route begins


const login = async (req, res) => {
    // Our login logic starts here
    try {
        // Get user input
        const { username, password } = req.body;

        postUser.findOne({ username })
            .then(user => {
                if (user) {
                    bcrypt.compare(password, user.password, function (err, result) {

                        if (err) {
                            res.json({
                                error: err
                            })
                        }
                        if (result) {
                            let token = jwt.sign({ username: user.username }, 'verySecretValue', { expiresIn: '1h' })
                            res
                                .cookie("auth-token", token, {
                                    httpOnly: true,
                                    secure: process.env.NODE_ENV === "production",
                                })
                            res.status(201).json({
                                message: 'Login Successful',
                                token: token
                            })

                        } else {
                            res.status(400).send("Blank userName/password")
                        }
                    }
                    )

                } else {
                    res.json({
                        message: 'No User Found'
                    })
                }

            })
    }
    catch (err) {
        console.log(err);
    }
    //route 1 ends here
};

//route no.2=log out route
const logout = async (req, res) => {
    // remove the req.user property and clear the login session
    req.logout;
    username = postUser.username;
    // line to destroy session data
    //req.session = null;
    //jwt.destroy(token)
    //a clever way to make jwt token expire on logout
    const token = jwt.sign(
        { user_id: user._id, username },
        process.env.TOKEN_KEY,
        { expiresIn: "1s" }
    );
    //
    if (logout) {
        res.send({ msg: "You have been Logged Out" });
        // redirect to homepage
        res.redirect("/");
    } else {
        res.send({ msg: "Error" });
    }
}; //route no.2 log out route ends here

//route no.4 :Return user information route
const userInfo = async (req, res) => {
    postUser.find({}, function (err, result) {
        if (err) throw err;
        res.json(result);
    });
};

const validate = function (req, res) {
    try {
      console.log(req.cookie)
        const verify = jwt.verify(req.cookie['auth-token'], "verySecretValue")
        postUser.findOne({ username: verify.username, userRole: verify.role }, function (err, result) {
            if (err) {
                res.status(400).send(err)
            }
            else {
                if (result == null) {
                    res.status(401).send(false)
                }
                else {
                    res.status(202).send(verify)
                }
            }

        })



    } catch (error) {

        res.status(400).send(error)

    }

}

module.exports = { register, login, logout, userInfo, validate };