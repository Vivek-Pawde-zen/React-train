//var dbHost = 'mongodb://localhost:27017/PanelManagement';
//mongoose.connect(dbHost);
const slotSchema1 = require("./../schema/slotSchema");
const express = require("express");
const jwt = require("jsonwebtoken");

getSlot = async (req, res) => {
  const getSlot = await slotSchema1.find();
  jwt.verify(req.token, process.env.TOKEN_KEY, (err, authData) => {
    if (err) {
      res.sendStatus(403);
    } else {
      res.json({
        getSlot,
      });
    }
  });
};
//CREATE Request Handler
//CREATE New slot Information
createSlot = async (req, res) => {
  //const { error } = validatepanel(req.body);
  //if (error){
  //res.status(400).send(error.details[0].message)
  //return;
  //};
  //Increment the panel id
  const slotinfo = new slotSchema1(req.body);
  jwt.verify(req.token, process.env.TOKEN_KEY, (err, authData) => {
    if (err) {
      res.sendStatus(403);
    } else {
      slotinfo.save().then(() => {
        res.status(201).send(slotinfo);
      });
    }
  });
};

//Update Request Handler
// Update Existing slot Information
updateSlot = async (req, res) => {
  slotSchema1.find({ slotId: req.params.slotId }, function (err, result) {
    if (err) throw err;
    if (!result) {
      res.json({
        message: "Slot with id: " + req.params.panelId + " not found.",
      });
    }
    jwt.verify(req.token, process.env.TOKEN_KEY, (err, authData) => {
      if (err) {
        res.sendStatus(403);
      } else {
        if(req.body.slotId==null)
        {
          result.slotId = result.slotId;
        }
        if(req.body.panelName==null)
        {
          result.panelName = result.panelName;
        }
        if(req.body.startDate==null)
        {
          result.startDate = result.startDate;
        }
        if(req.body.endDate==null)
        {
          result.endDate = result.endDate;
        }
        if(req.body.time1==null)
        {
          result.time1 = result.time1;
        }
        if(req.body.duration==null)
        {
          result.duration = result.duration;
        }
        if(req.body.slotused==null)
        {
          result.slotused = result.slotused;
        }
        if(req.body.active==null)
        {
          result.active = result.active;
        }
        if(req.body.slotId!=null)
        {
          result.slotId = req.body.slotId;
        }
        if(req.body.panelName!=null)
        {
          result.panelName = req.body.panelName;
        }
        if(req.body.startDate!=null)
        {
          result.startDate = req.body.startDate;
        }
        if(req.body.endDate!=null)
        {
          result.endDate = req.body.endDate;
        }
        if(req.body.time1!=null)
        {
          result.time1 = req.body.time1;
        }
        if(req.body.duration!=null)
        {
          result.duration = req.body.duration;
        }
        if(req.body.slotused!=null)
        {
          result.slotused = req.body.slotused;
        }
        if(req.body.active!=null)
        {
          result.active = req.body.active;
        }
        

        result.save(function (err, result) {
          if (err) throw err;
          res.json({
            message: "Successfully updated the slot",
            slotSchema: result,
          });
        });
      }
    });
  });
};

//Delete Request Handler
// Delete slot Details
deleteSlot = async (req, res) => {
  jwt.verify(req.token, process.env.TOKEN_KEY, (err, authData) => {
    if (err) {
      res.sendStatus(403);
    } else {
      slotSchema1.findOneAndRemove(
        { slotId: req.params.slotId },
        function (err, result1) {
          res.json({
            message: "Successfully deleted the Slot",
            slotSchema: result1,
          });
        }
      );
    }
  });
};

//Get unused slots
getUnusedSlot = async (req, res) => {
  const unusedslots = await slotSchema1.find({
    slotused: false,
  });
  jwt.verify(req.token, process.env.TOKEN_KEY, (err, authData) => {
    if (err) {
      res.sendStatus(403);
    } else {
      res.json({
        unusedslots,
      });
    }
  });
};

// Get highest slot provider
getHighestSlot = async (req, res) => {
//   slotId1 = slotSchema1.slotId;
//   const high = await slotSchema1.find({
//     slotId1,
//   });
//   console.log(high.slotId);
//   slotSchema1.find({ slotId: high.slotId }, function (err, result) {
//     if (err) throw err;
//     console.log(result);
//   });
// };
// var i = 0;
// const count = [];
// const hcount = [];
// while (i < slotSchema1.length) {
//   if (count[slotSchema1.slotId]) {
//     count[slotSchema1.slotId] += 1;
//   } else {
//     count[slotSchema1.slotId] = 1;
//   }
//   i++;
// }

slotSchema1.find({ slotId: '2' }, function (err, result) {
    if (err) throw err;
    jwt.verify(req.token, process.env.TOKEN_KEY, (err, authData) => {
      if (err) {
        res.sendStatus(403);
      } else {
        res.json({
          result
        });
      }
    });
  });
}

module.exports = {
  createSlot,
  updateSlot,
  deleteSlot,
  getHighestSlot,
  getUnusedSlot,
  getSlot,
};
