import React from 'react';
import MathsBooks from '../molecules/maths_books';
import Label from '../atoms/label';

const MathsBookSection = () => {
  return (
    <div>
      <Label value="Choose math book:" />
      <MathsBooks />
    </div>
  );
};

export default MathsBookSection;