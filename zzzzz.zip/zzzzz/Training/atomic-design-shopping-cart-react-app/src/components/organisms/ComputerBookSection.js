import React from 'react';
import ComputerBooks from '../molecules/computer_books';
import Label from '../atoms/label';

const ComputerBookSection = () => {
  return (
    <div>
      <Label value="Choose computer book(s):" />
      <ComputerBooks />
    </div>
  );
};

export default ComputerBookSection;