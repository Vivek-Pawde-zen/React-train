import React from 'react';
import ShoppingCartList from '../molecules/shopping_cart_list';
import Label from '../atoms/label';

const ShoppingCartSection = () => {
  return (
    <div>
      <Label value="Shopping Cart:" />
      <ShoppingCartList />
    </div>
  );
};

export default ShoppingCartSection;