import React from 'react';

const Label = ({ value }) => {
  return <label>{value}</label>;
};

export default Label;