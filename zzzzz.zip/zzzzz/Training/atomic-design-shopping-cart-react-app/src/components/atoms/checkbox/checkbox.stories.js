import Checkbox from './checkbox';

export default{
    title:'Checkbox',
    component:Checkbox

}


export const Disabled =() => <Checkbox value="Disabled Checkbox" disabled />;
export const Checked =() => <Checkbox value="Checked Checkbox" checked />;
export const Unchecked =() => <Checkbox value="Unchecked Checkbox" />;
