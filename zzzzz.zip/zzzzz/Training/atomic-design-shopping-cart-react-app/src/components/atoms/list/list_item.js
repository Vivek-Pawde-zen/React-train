import React from 'react';

const ListItem = ({ value }) => {
  return <li>{value}</li>;
};

export default ListItem;