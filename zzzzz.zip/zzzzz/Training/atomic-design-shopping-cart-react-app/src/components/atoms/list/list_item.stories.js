import React from 'react';



import ListItem from './list_item';
const items = ['Item 1', 'Item 2', 'Item 3'];

export default{
    title:'ListItem',
    component:ListItem

}


export const Bullet_List= () => (
    <ul>
      {items.map((item, index) => (
        <ListItem key={index} value={item} type="bullet" />
      ))}
    </ul>);
  export const Numbered_List= () => (
    <ol>
      {items.map((item, index) => (
        <ListItem key={index} value={item} type="numbering" />
      ))}
    </ol>);

