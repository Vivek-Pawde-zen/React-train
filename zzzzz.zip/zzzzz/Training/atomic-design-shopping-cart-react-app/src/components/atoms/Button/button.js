import React from 'react';
import './button.css'

const Button = (props) => {


  const {variant,children} =props;
  return (
    <button className={`button ${variant}`}>{children}</button>
  )
};

export default Button;