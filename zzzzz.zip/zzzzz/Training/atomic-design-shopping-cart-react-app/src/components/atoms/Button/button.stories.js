
import Button from './button';

export default{
    title:'Button',
    component:Button

}


export const primary =()=><Button varaint='primary'>Primary</Button>
export const Secondary =()=><Button varaint='Secondary'>Secondary</Button>
export const Success =()=><Button varaint='Success'>Success</Button>
export const Danger =()=><Button varaint='Danger'>Danger</Button>