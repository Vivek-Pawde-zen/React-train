import React from 'react';
import Label from './label';

export default{
    title:'Label',
    component:Label

}


export const Title= () => <Label type="title" value='This is a Title'>This is a Title</Label>
export const Checkbox_List_Label= () => <Label type="checkbox_list_label"value='Choose your options:'>Choose your options:</Label>;
export const Bullet_List_Label= () => <Label type="bullet_list_label" value='List of items:'>List of items:</Label>;
