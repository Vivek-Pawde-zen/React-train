import React from 'react';
import ShoppingCartSection from '../organisms/ShoppingCartSection.js';
import Button from '../atoms/button.js';
import { useNavigate } from 'react-router-dom';

const ShoppingCartPage = () => {
  const navigate = useNavigate();

  const handleHomeButtonClick = () => {
    navigate('/');
  };

  return (
    <div>
      <ShoppingCartSection />
      <Button value="Home" onClick={handleHomeButtonClick} disabled={false} />
    </div>
  );
};

export default ShoppingCartPage;