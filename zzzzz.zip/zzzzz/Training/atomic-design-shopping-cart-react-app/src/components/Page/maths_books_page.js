import React from 'react';
import MathsBookSection from '../organisms/MathsBookSection.js';
import Button from '../atoms/button.js';
import { useNavigate } from 'react-router-dom';

const MathsBookPage = () => {
  const navigate = useNavigate();

  const handleShowButtonClick = () => {
    navigate('/shopping-cart-page');
  };

  return (
    <div>
      <MathsBookSection />
      <Button value="Show" onClick={handleShowButtonClick} disabled={false} />
    </div>
  );
};

export default MathsBookPage;