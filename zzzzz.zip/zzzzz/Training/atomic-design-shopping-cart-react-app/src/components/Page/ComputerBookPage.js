import React from 'react';
import ComputerBookSection from '../organisms/ComputerBookSection.js'
import Button from '../atoms/button.js';

import { useNavigate } from 'react-router-dom';

const ComputerBookPage = () => {
  const navigate = useNavigate();

  const handleNextButtonClick = () => {
    navigate('/maths-book-page');
  };

  return (
    <div>
      <ComputerBookSection />
      <Button value="Next" onClick={handleNextButtonClick} disabled={false} />
    </div>
  );
};

export default ComputerBookPage;