import React, { useContext } from 'react';
import ListItem from '../atoms/list_item';

const ShoppingCartList = () => {

  return (
    <ul>
      <ListItem value={ 'No computer book selected'} />
      <br></br>
      <ListItem value={'No math book selected'} />
    </ul>
  );
};

export default ShoppingCartList;