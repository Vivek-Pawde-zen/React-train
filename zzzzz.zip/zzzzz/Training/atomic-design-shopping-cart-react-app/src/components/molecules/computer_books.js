import React, { useContext } from 'react';
import Checkbox from '../atoms/checkbox.js';

const ComputerBooks = () => {

  const handleCheckboxChange = (event) => {
    
  };

  return (
    <div>
      <Checkbox value="Core Java"  onChange={handleCheckboxChange} />
      <br></br>
      <Checkbox value="Python"  onChange={handleCheckboxChange} />
      <br></br>
      <Checkbox value="Angular"  onChange={handleCheckboxChange} />
      <br></br>
    </div>
  );
};

export default ComputerBooks;