import React from 'react';
import Checkbox from '../atoms/checkbox.js';

const MathsBooks = () => {

  const handleCheckboxChange = (event) => {
   
  };

  return (
    <div>
      <Checkbox value="Algebra"  onChange={handleCheckboxChange} />
      <br></br>
      <Checkbox value="Geometry" onChange={handleCheckboxChange} />
      <br></br>
    </div>
  );
};

export default MathsBooks;