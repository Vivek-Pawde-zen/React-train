import React from 'react';
import { BrowserRouter , Routes, Route } from 'react-router-dom';

import ComputerBookPage from './components/Page/ComputerBookPage';
import Maths_books_page from './components/Page/maths_books_page';
import Shopping_cart_page from './components/Page/shopping_cart_page';

const App = () => {
  return (
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<ComputerBookPage />} />
          <Route path="/book" element={<Maths_books_page />} />
          <Route path="/cart" element={<Shopping_cart_page />} />
        </Routes>
        </BrowserRouter>

  );
};

export default App;