import React from "react";
import ReactDOM from "react-dom";
import Cart from './Cart.js';
import "./index.css";

const App = () => (
  <div >
      <h1>Shopping Cart Page</h1>
      <td></td>
      <p>Selected Comp Book: </p>
      <td></td>
      <p>Selected Maths Book: </p>
      <td></td>
      <button onClick={() => handleEvent()}>Home</button>
      <td></td>

  </div>
);
ReactDOM.render(<App />, document.getElementById("app"));
