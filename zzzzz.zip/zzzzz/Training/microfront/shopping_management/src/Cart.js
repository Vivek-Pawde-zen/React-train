import React from 'react';
import { useNavigate } from 'react-router-dom';

const Cart = () => {
  const navigate = useNavigate();

const handleEvent = () => {``
  navigate('/');
};
  return (
    <div>
      <h1>Shopping Cart Page</h1>
      <td></td>
      <p>Selected Comp Book: </p>
      <td></td>
      <p>Selected Maths Book: </p>
      <td></td>
      <button onClick={() => handleEvent()}>Home</button>
      <td></td>

    </div>
  );
};

export default Cart;