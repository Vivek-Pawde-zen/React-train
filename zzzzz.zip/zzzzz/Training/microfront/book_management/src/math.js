import React from 'react';
import {  useNavigate } from 'react-router-dom';
const Book = () => {
  const navigate = useNavigate();

  const handleSelection = (book) => {
    navigate('/cart');
  };

  return (
    <div >
      <h1>Select a Math Book</h1>
      <button onClick={() => handleSelection('Algebra')}>Algebra</button>
      <td></td>
      <button onClick={() => handleSelection('Geometry')}>Geometry</button>

    </div>
  );
};

export default Book;