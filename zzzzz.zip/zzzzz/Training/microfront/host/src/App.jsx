import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter , Routes, Route } from 'react-router-dom';
import "./index.css";
import Cart from 'shopping_management/Cart';
import Book from 'book_management/math';
import Home from 'book_management/comp';

const App = () => (
  <div >


    <BrowserRouter>
    <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/book" element={<Book/>} />
          <Route path="/cart" element={<Cart />} />
    </Routes>
    </BrowserRouter>
  </div>
);


ReactDOM.render(<App />, document.getElementById("app"));
