import './App.css';
// import callMe from './00immutability';
import callMe from './01basic-setup';

function App() {
  callMe()
  return (
    <div className="App">
      <h1>Redux Demo</h1>
    </div>
  );
}

export default App;
