
let callMe = () =>{
    console.log('Immutability!');

    var a = {name:'Abhijeet',things:[11,22,33]};
    var b = Object.assign({},a,{name:'Ashish'});// returns a brand new object

    // console.log(a)
    // console.log(b)

    //b.things = a.things.concat(44,55);// returns a brand new object

    // console.log(a.things)
    // console.log(b.things)

    // b.things = a.things.filter(v => v!==22); // returns a brand new object
    // console.log(a.things)
    // console.log(b.things)

    // Currying Function
    // Currying is the technique of evaluating function with multiple
    // arguments into a sequence of functions with a single argument.

    // function log(type, msg) {
    //     if (type == "error")
    //       console.error(msg);
    //     if (type == "warn")
    //       console.warn(msg);
    //     if (type == "info")
    //       console.info(msg);
    //   }

    // //   const error = msg => log("error",msg);
    // //   const warn = msg => log("warn",msg);
    // //   const info = msg => log("info",msg);

    //   function curry(func){
    //     return function(x){           
    //             return func(x);
    //     }
    //   }
    //   // with currying
    //   log = curry(log);
    //   const error = log('error')
    //   const warn = log('warn')
    //   const info = log('info')
    //   // Currying more shorter, concise and more readable

    function add(x,y){
        return x+y;
    }
    console.log('Addition is '+add(4,5));

    // Currying Fun
    function sum(x){
        return function(y){
            return x+y;
        }
    }
    
    console.log('Addition is '+sum(4)(5));
}

export default callMe;