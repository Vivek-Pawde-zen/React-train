// Using Redux
// import {createStore} from 'redux'

// let callMe = () =>{

//     function counterReducer(state={value:0},action){
//         switch(action.type){
//             case 'counter/increment':               
//                 return {value:state.value + 1};
//             case 'counter/decrement':
//                 return {value:state.value - 1};
//             default:
//                 return state;
//         }
//     }

//     let store = createStore(counterReducer);

//     store.subscribe(() => console.log(store.getState()));

//     // dispatch the actions
//     store.dispatch({type:'counter/increment'})
//     store.dispatch({type:'counter/decrement'})
//     store.dispatch({type:'counter/increment'})

//     console.log('\n');
// }

// export default callMe;


// Using redux-toolkit

import {configureStore, createSlice} from '@reduxjs/toolkit';

let callMe = () =>{

    const counterSlice = createSlice({
        name:'counter',
        initialState:{value:0},
        reducers:{
            increment: state =>{
            // Redux Toolkit allows us to write 'mutating' logic
            // in reducers. It doesn't actually mutate the state
            // because it uses the Immer Library, which detects
            // changes to a 'draft state' and produces a brand new
            // immutable state based off those changes.
                console.log('increment!')
                state.value += 1;
            },
            decrement: state =>{
                console.log('decrement!')
                state.value -= 1;
            }
        }
    })

    const {increment,decrement} = counterSlice.actions;

    let store = configureStore({
        reducer: counterSlice.reducer
    })

    store.subscribe(() => console.log(store.getState()));

    // dispatch the actions
    store.dispatch(increment())
    store.dispatch(increment())
    store.dispatch(decrement())

    console.log('\n');
}

export default callMe;