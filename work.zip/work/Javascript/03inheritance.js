// // Inheritance

// // 3 ways
// // Prototype Chaining
// // Classical Inheritance / COTR Stealing
// // Psuedo Classical Inheritance - combination of above two

// // Prototype Chaining
// function Parent(relation){
//     this.relation = relation;
//     // CTOR Level
//     this.jobs = ['Service','Business'];
//     this.show = function(){
//         console.log(this.relation);
//     }
// }
// // Prototype Chaining
// Child.prototype = new Parent('Mother');
// Child.prototype.constructor = Child; // To have proper execution of constructor sequence

// function Child(rel){
// }

// var child1 = new Child('son');
// var child2 = new Child('daughter');

// child1.show();
// child2.show();

// console.log(child1.jobs);
// console.log(child2.jobs);
// child1.jobs.push('Retired');
// console.log(child1.jobs);
// console.log(child2.jobs);

// // Limitations of Prototype Chaining
// // 1 Inherited properties of parent becomes 
// // prototype level property
// // 2 Argument can't be passed to super/base class
//     // from sub/derived class.

// // call and apply
// var person1 = {name:"Sachin",city:'Mumbai'};
// var person2 = {name:'Rahul',city:'Bengaluru'};

// var sayHello = function(){
//     console.log('Hello '+this.name+' from '+this.city);
// }
// //sayHello();
// //sayHello(person1);
// //person1.sayHello();

// // call
// sayHello.call(person1);
// sayHello.call(person2);

// var updateInfo = function(name,city){
//     this.name = name;
//     this.city = city;
// }

// updateInfo.call(person1,'Mahi','Ranchi');
// sayHello.call(person1);

// var arr = ['Yuvi','Chandigarh'];
// updateInfo.apply(person2,arr);
// sayHello.call(person2);

// Classical Inheritance
function Parent(relation){
    this.relation = relation;
    // CTOR Level
    this.jobs = ['Service','Business'];
    this.show = function(){
        console.log(this.relation);
    }
}
Parent.prototype.parentPrototypeMethod = function(){
    console.log('Inside Parent Prototype Method!');
}

function Child(rel){
    // Classical Inheritance
    Parent.call(this,rel);
}


var child1 = new Child('son');
var child2 = new Child('daughter');

child1.show();
child2.show();

console.log(child1.jobs);
console.log(child2.jobs);
child1.jobs.push('Retired');
console.log(child1.jobs);
console.log(child2.jobs);

child1.parentPrototypeMethod();

// Limitations of Classical Inheritance
// 1. No function reuse - at memory level
// 2. Child can't access methods defined on parent's prototype level