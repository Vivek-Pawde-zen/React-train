"use strict"

let g = 9;

function foo(){
    var l = 6;
    y = 11;
    //var x;
    {
        var x = 5;// javascript hoisting - declaration to be hoisted at the
                    // begining of the function
       // x = 5;
    }
    console.log('g '+g +' l '+l+' x '+x+' y '+y);
}

foo();

console.log('g '+g+' y '+y);
