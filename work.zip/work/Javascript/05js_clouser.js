// // without closure

// //var hits = 0; // global variable

// function showHits(){
//     var hits = 0;
//     hits++;
//     return hits;
// }

// console.log(showHits());
// console.log(showHits());
// hits = 8;
// console.log(showHits());

// Javascript Closure - Is about retaining the environment of the 
// outer function within inner function, even though
// inner function is getting executed outside of the outer function.

// With Closure

// var foo = (function(){
//             return 10;
//             })(); // IIFE

//console.log(foo());

// function foo(){
// }
// console.log(foo);

var getHits = (function(){
                    var hits = 0;
                    function addHits(){
                        hits++;
                        return hits;
                    }
                    return addHits;
                })();

console.log(getHits());
console.log(getHits());