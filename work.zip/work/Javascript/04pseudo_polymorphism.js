// Pseudo classical inheritance

// Base class Human
// Derived class Student

function Human(nm){
    this.name = nm;
}

Human.prototype.speak = function(){
    console.log('I speak English!');
}
Human.prototype.introduction = function(){
    console.log('Hello, this is '+this.name);
}

// Prototype Chaining
Student.prototype = new Human();
Student.prototype.constructor = Student;

function Student(nm,college,courses){
    // classical inheritance
    Human.call(this,nm);
    this.college = college;
    this.courses = courses;
}
Student.prototype.takeExams = function(){
    console.log('This is exam time!');
}

// Function Overriding
Student.prototype.introduction = function(){
    console.log('Hi, I am '+this.name+', I am a student of '+this.college+
    ' and I study '+this.courses);
}

var person = new Human('Jinal');
person.speak();
//person.introduction();


var stud = new Student('Abhishek','VIIT',['Javascript','React','Node']);
stud.speak();
//stud.introduction();

letMeIntroduce(stud);

function letMeIntroduce(obj){
    obj.introduction(); // polymorphism
}