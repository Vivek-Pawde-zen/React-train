
// ES 5

function Person(){ // class / ctor / function
    this.id = 100; // public property
    var name = 'default';
    // ctor level
    // this.hobbies  = ['Music','Cricket'];

    this.setName = function(nm){
        name = nm;
    }
    this.getInfo = function(){
        return this.id+' '+name;
    }
}

// Prototype Level - that is being shared among all the objects
Person.prototype.hobbies  = ['Music','Cricket'];

//Person.prototype = new Object();

var p1 = new Person();
p1.setName('Sachin');
console.log(p1.getInfo());

var p2 = new Person();
p2.setName('Rahul');
console.log(p2.getInfo());


p1.hobbies.push('Computer Games');

console.log(p1.hobbies);
console.log(p2.hobbies);

