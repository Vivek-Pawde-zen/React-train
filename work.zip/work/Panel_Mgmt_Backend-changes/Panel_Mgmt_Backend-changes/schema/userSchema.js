const { bool, boolean } = require("joi");
const mongoose = require("mongoose");

const userSchema = mongoose.Schema({
  userRole:{
    type:String

  },
  username: {
    type: String,
    require: true,
  },
  password: {
    type: String,
    require: true,
  },
  firstname: {
    type: String,
    require: true,
  },
  lastname: {
    type: String,
  },
  email: {
    type: String,
    require: true,
  },
  phone: {
    type: String,
    require: true,
  },
  panelName:{
    type : String,
    require:true,
  },
  skills:{
    type: String,
    require : true,
  },
  active:{
    type : Boolean,
    require : true,
  },
  token: {
    type: String,
    require: true,
  },
});

module.exports = mongoose.model("user", userSchema);
