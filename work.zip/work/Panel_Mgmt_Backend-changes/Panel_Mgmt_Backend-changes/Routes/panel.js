const express = require("express"); //import express
const router = express.Router();
const panel = require("./../Controller/panel");
//const verify = require("./../Middleware/auth");


router.get("/getPanel", panel.getPanel);
router.get("/:panelId", panel.getPanelById);
router.get("/:skills", panel.getPanelBySkills);
router.post("/createPanel", panel.createPanel);
router.put("/:panelId", panel.updatePanel);
router.delete("/:panelId", panel.deletePanel);


module.exports = router;