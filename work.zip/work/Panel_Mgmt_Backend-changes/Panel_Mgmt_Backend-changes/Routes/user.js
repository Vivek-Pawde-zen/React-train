const express = require("express"); //import express
const router = express.Router();
const user = require("./../Controller/user");
//const auth = require("../middleware/auth");

router.post("/register", user.register);
router.post("/login", user.login);
router.get("/logout", user.logout);
router.get("/userinfo", user.userInfo);
router.get("/validate", user.validate);

module.exports = router; // export to use in server.js