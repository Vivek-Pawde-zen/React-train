const express = require("express"); //import express
const router = express.Router();
const slot = require("./../Controller/slot");
//const slot1 = require("./../Controller/slot1");

router.get("/getSlot",getSlot);
router.get("/unusedslots", slot.UnusedSlot);
router.get("/highestslot", slot.highestSlot);
router.get("/:slotId",slot.getSlotById);
router.post("/createSlot", createSlot);
router.put("/:slotId", updateSlot);
router.delete("/:slotId", deleteSlot);



module.exports = router;