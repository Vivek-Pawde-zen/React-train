//var dbHost = 'mongodb://localhost:27017/PanelManagement';
//mongoose.connect(dbHost);
const slotSchema1 = require("./../schema/slotSchema");
const express = require("express");
const jwt = require("jsonwebtoken");

getSlot = async (req, res) => {
  const getSlot = await slotSchema1.find();
      res.json({
        getSlot,
      }); 
};

getSlotById = async (req, res) => {
 
      //logic for getPanelBySkills
      slotSchema1.findOne({ slotId : req.params.slotId }, function (err, result) {
          if (err) {
              res.sendStatus(403);
          } else {
              res.json({
                  result,
              });
          }
      });
}
//CREATE Request Handler
//CREATE New slot Information
createSlot = async (req, res) => {
  console.log("In create slot");
 
  const { slotId, panelName, startDate, endDate, starttime, endtime, skills, slotused, active } = req.body;
  console.log(req.body.starttime);
        const slotinfo = new slotSchema1({ slotId, panelName, startDate, endDate, starttime, endtime, skills, slotused, active });
        slotinfo.save().then(() => {
            res.status(201).send(slotinfo);
        });
  // const slotinfo = new slotSchema1(req.body); // getting all info from body
  // console.log(req.body);
  //     slotinfo.save().then(() => {
  //       res.status(201).send(slotinfo);
  //     });
  //     console.log(req.body);
};

//Update Request Handler
// Update Existing slot Information
updateSlot = async (req, res) => {

  slotSchema1.findOne({ slotId: req.params.slotId }, function (err, result) {
    if (err) throw err;
    if (!result) {
      res.json({
        message: "Slot with id: " + req.params.slotId + " not found.",
      });
    }
    if(req.body.slotId!=null)
    {
      result.slotId = req.body.slotId;
      console.log(result.slotId);
    }
          if(req.body.slotId!=null)
          {
            res.json({
              message : "You cannot change slotId"
            })
          }
          else
          {
              
                result.panelName = req.body.panelName;
              
                result.startDate = req.body.startDate;
              
                result.endDate = req.body.endDate;
              
                result.starttime = req.body.starttime;
              
                result.endtime = req.body.endtime;

                result.skills = req.body.skills;
              
                result.slotused = req.body.slotused;
              
                result.active = req.body.active;
              
              result.save(function (err, result) {
                if (err) throw err;
                res.json({
                    message: "Successfully updated the panel",
                    slotSchema: result
                });
            });
        }
});
}


//Delete Request Handler
// Delete slot Details
deleteSlot = async (req, res) => {

    if (err) {
      res.sendStatus(403);
    } else {
      slotSchema1.findOneAndRemove(
        { slotId: req.params.slotId },
        function (err, result1) {
          res.json({
            message: "Successfully deleted the Slot",
            slotSchema: result1,
          });
        }
      );
    }
};

//Get unused slots
UnusedSlot = async (req, res) => 
{
    console.log("In unused slot")
    const unusedslots = await slotSchema1.find({
      slotused: false,
    });
    
    res.json({
          unusedslots,
    });
};

// Get highest slot provider
highestSlot = async (req, res) => {
  console.log("get highest slot")
  const getSlot = await slotSchema1.find();
  var ls=[];
  var i=0;
  while(i<getSlot.length)
  {
  
    ls.push(getSlot[i].panelName);
    i++;
  }
  let counts={}
  ls.forEach(function (x) { counts[x] = (counts[x] || 0) + 1; });
  console.log(counts)
  res.json({counts});
}

module.exports = {
  createSlot,
  updateSlot,
  deleteSlot,
  UnusedSlot,
  highestSlot,
  getSlot,
  getSlotById
};
