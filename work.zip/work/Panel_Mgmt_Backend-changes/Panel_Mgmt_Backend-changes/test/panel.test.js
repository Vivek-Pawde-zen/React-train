let mongoose = require("mongoose");
let panel = require('./../schema/panelSchema');

let chai = require('chai');
let chaiHttp = require('chai-http');
let server = require('../server');
let should = chai.should();


chai.use(chaiHttp);

describe('panel', () => {
    beforeEach((done) => {
        panel.remove({}, (err) => { 
           done();           
        });        
    });
  describe('/GET book', () => {
      it('it should GET all', (done) => {
            chai.request(server)
            .get('/panel')
            .end((err, res) => {
                  res.should.have.status(200);
                  res.body.should.be.a('array');
                  res.body.length.should.be.eql(0);
              done();
            });
      });
  });
});
  describe('/POST panel', () => {

      it('it should POST a panel', (done) => {
          let newPanel = {
            panelId:1,
            panelName: 'java',
            skills:'java',
            Interviewer:'xyz',
            Active:false,
              
          }
            chai.request(server)
            .post('/panel')
            .send(newPanel)
            .end((err, res) => {
                  res.should.have.status(201);
                  res.body.should.be.a('object');
                  res.body.should.have.property('panelId').eql(1);
                  res.body.should.have.property('panelName').eql('java');
                  res.body.should.have.property('skills').eql('java');
                  res.body.should.have.property('Interviewer').eql('xyz');
                  res.body.should.have.property('Active').eql(false);
              done();
            });
      });
  });
  
  describe('/GET/:skills', () => {
      it('it should GET a panel by the given skill', (done) => {
          let newPanel = new panel({ panelId:2,
          panelName: "python",
          skills:"python",
          Interviewer:"abc",
          Active:false });
          newPanel.save((err, panel) => {
              chai.request(server)
            .get('/panel/' + panel.skills)
            .send(panel)
            .end((err, res) => {
                  res.should.have.status(200);
                  res.body.should.be.a('object');
                  res.body.should.have.property('panelName').eql('python');
                  res.body.should.have.property('skills').eql('python');
              done();
            });
          });

      });
  });
  
  describe('/PUT/:panelId', () => {
      it('it should UPDATE a panel given the panelId', (done) => {
          let newPanel = new panel({panelId:3,
          panelName: "react",
          skills:"react",
          Interviewer:"xyz",
          Active:false })
          newPanel.save((err, panel) => {
                chai.request(server)
                .put('/panel/' + panel.panelId)
                .send({panelId:3,
                panelName: "react",
                skills:"react",
                Interviewer:"abc",
                Active:false })
                .end((err, res) => {
                      res.should.have.status(200);
                      res.body.should.be.a('object');
                      res.body.should.have.property('message').eql('Successfully updated the panel');
                      res.body.panelSchema.should.have.property('Interviewer').eql('abc');
                  done();
                });
          });
      });
  });
 /*
  * Test the /DELETE/:id route
  */
  describe('/DELETE/:panelId panel', () => {
      it('it should DELETE a panel given the panelId', (done) => {
          let newPanel = new panel({"panelId": 4,
          "panelName": "bootstrap",
          "skills": "bootstrap",
          "Interviewer": "xyz",
          "Active": false,})
          newPanel.save((err, panel) => {
                chai.request(server)
                .delete('/panel/' + panel.panelId)
                .end((err, res) => {
                      res.should.have.status(200);
                      res.body.should.be.a('object');
                      res.body.should.have.property('message').eql('Successfully deleted the panel');
                      res.body.panelSchema.should.have.property('panelId').eql(4),
                  done();
                });
          });
      });
  });