const express = require("express");
const jwt = require("jsonwebtoken");
const auth = require("./../Middleware/auth");


//const User = require(./model/user");
const User =[
    { "username": "xyz","password" : "secret", "firstname": "x", "lastname": "z", "email": "xyz@123", "phone": "123"},
    { "username": "abc","password" : "secret", "firstname":"a", "lastname": "c", "email": "abc@123", "phone": "456"}
    ]   
    
    
function register (req, res) 
{  
        
          // Get user input
          //const { username, password, firstname,lastname,email, phone } = req.body;
          
          // Validate user input
          //if (!(username&&email && password && firstname && lastname&&phone)) {
          //  res.send("All input fields are required");
         // }
      
          // check if user already exist
          // Validate if user exist in our database
          //const oldUser = await User.findOne({ username });
          //const oldUser = User.find({ username });  
      
          //if (oldUser) {
           // return res.send("User Already Exists. Please Login");
         // }
      
          //Encrypt user password
          //encryptedPassword = bcrypt.hash(password, 10);
          const nuser= {
            username: req.body.username,
            password:req.body.password,
            firstname:req.body.firstname,
            lastname:req.body.lastname,
            email:req.body.email,
            phone:req.body.phone
            };
            User.push(nuser);
          // Create user in our database
          //const user = User.create({
            //
            //username, 
            //password:encryptedPassword, 
           // firstname,
            //lastname,
            //email, 
            //phone
         // });
      
          // Create token
          //const token = jwt.sign(
          //  { user_id: user._id, username },
           // process.env.TOKEN_KEY,
           // {
             // expiresIn: "9h",
           // }
          //);
          // save user token
          //user.token = token;
      
          // return new user
          res.json(nuser);
        
       
} // Our route 3 registeration  ends here

///route 1: log in route begins
function login (req, res) 
{

    // Our login logic starts here
      // Get user input
     // const username = req.body.username;
      //const password = req.body.password;
      // Validate user input
      //if (!username ) {
      //  res.send("All input is required");
      //}
      // Validate if user exist in our database
      //const user = await User.findOne({ username });
      //const user = User.find(o => o.username === (req.params.username)); 
      let o = User.find(o => o.username === req.body.username && o.password === req.body.password); 
      //if ((username == User.find(o => o.username === (req.params.username))) && (password == User.find(o => o.password === (req.params.password)))) 
      //if (User.username == req.params.username && User.password == req.params.password) 
      console.log(req.body.username);
      if(o)
      {
        /* Create token
        const token = jwt.sign(
          { user_id: user._id, username },
          process.env.TOKEN_KEY,
          {
            expiresIn: "9h",
          }
        );
  
        // save user token
        user.token = token;*/
  
        // user
        res.send("User has logged in successfully");
      }
      else
      {
        res.send("Invalid Credentials");
      }
      
      
    
    //route 1 ends here
}


  //route no.2=log out route
function logout (req, res) 
{
    // remove the req.user property and clear the login session
    //req.p.logout();
  
    // line to destroy session data
    //req.session = null;
    //jwt.destroy(token)
    //a clever way to make jwt token expire on logout
   // const token = jwt.sign({ user_id: user._id, username },process.env.TOKEN_KEY,{expiresIn: "1s",});
    //
    if (logout) {
      res.send({msg : 'You have been Logged Out' });
      // redirect to homepage
      //res.redirect('/');
    } 
    else {
      res.send({msg:'Error'});
    }
 
} //route no.2 log out route ends here


//route no.4 :Return user information route
function userInfo (req, res) 
{

    res.json(User);
   
}      
  //route no.4 ends here

module.exports = { register, login, logout, userInfo}
