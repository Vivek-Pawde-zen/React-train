const slot=[
    { panel: 'ABCD',Status : "Not Booked", StartDate: '25/08/22', EndDate: '25/8/22', Time: '12:00', Duration: '1 hour',   skills:  'Java', slotused: false, id:1} 
    ]
//CREATE Request Handler
//CREATE New panel Information
function createSlot (req, res) {
 
    //const { error } = validatepanel(req.body);
    //if (error){
    //res.status(400).send(error.details[0].message)
    //return;
    //};
    //Increment the panel id
    const newslot = {
    id: slot.length + 1,
    name: req.body.name,
    skills:req.body.skills,
    };
    slot.push(newslot);
    res.send(newslot);
}

//Update Request Handler
// Update Existing slot Information
function updateSlot(req, res)
{
    const slot1 = slot.find(c=> c.id === parseInt(req.params.id));
    if (!slot1) res.status(404).send('<h2 style="font-family: Malgun Gothic; color: darkred;">Not Found!! </h2>');
     
    /*const { error } = validatepanel(req.body);
    if (error){
    res.status(400).send(error.details[0].message);
    return;
    }*/
    console.log(req.body.skills);
    slot1.skills = req.body.skills;
    console.log(req.body.skills);
    res.send(slot);
}

//Delete Request Handler
// Delete slot Details
function deleteSlot (req, res)  {
 
    const slotdelete = panel.find( c=> c.id === parseInt(req.params.id));
    if(!slotdelete) res.status(404).send('Not Found!!');
     
    const index = panel.indexOf(slotdelete);
    panel.splice(index,1);
     
    res.send(slotdelete);
    }

//Get unused slots
function getUnusedSlot (req, res) 
{
    unusedslot=[];
    let i=0;
    while(i<slot.length)
    {
        if(slot[i].slotused==false)
            unusedslot.push(slot[i]);    
        i++;
    }
    
    
    res.send(unusedslot);
}


// Get highest slot provider
function getHighestSlot (req, res) 
{
    const count = {};

    for (const element of slot) {
        if (slot[element].id) {
            count[element].id += 1;
        } 
        else {
            count[element] = 1;
        }
    }
    count.sort(function(a, b){return b-a});
    
    
    res.send(count[0]);
}

module.exports = { createSlot, updateSlot,deleteSlot, getHighestSlot, getUnusedSlot }
