
const panel=[
    {panel:'firstPanel',skills:'java',interviewer:'xyz',active:true,id:1},
    {panel:'firstPanel',skills:'react',interviewer:'abc',active:false,id:2},
    ] 
// Display the List Of panel when URL consists of api panel
function getPanel(req,res) 
{
    res.send(panel);
}
function getPanelBySkills (req, res) 
{
    const panelnew = panel.find(c => c.skills === (req.params.skills));
    //If there is no valid panel ID, then display an error with the following message
    if (!panelnew) res.status(404).send('Ooops... Cant find what you are looking for!');
    res.send(panelnew);
}
//CREATE Request Handler
//CREATE New panel Information
function createPanel (req, res){
 
    //const { error } = validatepanel(req.body);
    //if (error){
    //res.status(400).send(error.details[0].message)
    //return;
    //};
    //Increment the panel id
    const newPanel = {
    id: panel.length + 1,
    name: req.body.name,
    skills:req.body.skills,
    };
    panel.push(newPanel);
    res.send(newPanel);
}
//Update Request Handler
// Update Existing panel Information
function updatePanel (req, res)
{
    const panel1 = panel.find(c=> c.id === parseInt(req.params.id));
    if (!panel1) res.status(404).send('<h2 style="font-family: Malgun Gothic; color: darkred;">Not Found!! </h2>');
     
    /*const { error } = validatepanel(req.body);
    if (error){
    res.status(400).send(error.details[0].message);
    return;
    }*/
    panel1.skills = req.body.skills;
    res.send(panel);
}
//Delete Request Handler
// Delete panel Details
function deletePanel (req, res)
{
 
    const panelnew = panel.find( c=> c.id === parseInt(req.params.id));
    if(!panelnew) res.status(404).send('Not Found!!');
     
    const index = panel.indexOf(panelnew);
    panel.splice(index,1);
     
    res.send(panelnew);
}    
module.exports = { getPanel, getPanelBySkills, createPanel, updatePanel, deletePanel}
