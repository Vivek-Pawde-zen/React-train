const { number, string } = require("joi");
const mongoose=require("mongoose");


const panelSchema = mongoose.Schema({
    panelId:{
        type:Number,
        require:true
    },
    panelName:{
        type:String,
        require:true
    },
    skills:{
        type:String,
        require:true
    },
    Interviewer:{
        type:String,
        require:true
    },
    Active:Boolean,
    BookedStatus:{
        type:Boolean,
        require:true
    }
})

// const panelM= mongoose.model("panel",panelSchema);

module.exports=mongoose.model("panel",panelSchema);