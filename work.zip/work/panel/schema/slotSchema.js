const mongoose=require("mongoose")

const slotSchema= mongoose.Schema({
    slotId:{
        type:String,
        require:true
    },
    panelName:{
        type:String,
        require:true
    },
    startDate:{
        type:Date,
        require:true
    },
    endDate:{
        type:Date,
        require:true
    },
    time1:{
        type:String,
        require:true
    },
    duration:{
        type:String,
        require:true
    },
    slotused:{
        type:Boolean,
        require:true
    },
    active:{
        type:Boolean,
        require:true
    }


})

// const slot= mongoose.model('slot',slotSchema)

module.exports=mongoose.model('slot',slotSchema);