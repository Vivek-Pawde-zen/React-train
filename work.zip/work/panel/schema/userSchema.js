const mongoose=require('mongoose')

const userSchema= new mongoose.Schema({
    username:{
        type:String,
        require:true
    },
    password:{
        type:String,
        require:true
    },
    firstname:{
        type:String,
        require:true
    },
    lastname:{
        type:String
    }
    ,
    email:{
        type:String,
        require:true
    },
    phone:{
        type:String,
        require:true
    },
    token:{
        type:String,
        require:true
    }       
})

module.exports= mongoose.model('User',userSchema);

