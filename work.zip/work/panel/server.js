const express = require ('express');
// const routes = require('./routes'); // import the routes
const panelRoute = require('./Routes/panel')
const slotRoute = require('./Routes/slot')
const userRoute = require('./Routes/user')

const app = express();

app.use(express.json());

app.use('/pl', panelRoute); //to use the routes
app.use('/slot', slotRoute);
app.use('/user',userRoute);

const listener = app.listen(process.env.PORT || 8080, () => {
    console.log('Your app is listening on port ' + listener.address().port)
})

module.exports = app;