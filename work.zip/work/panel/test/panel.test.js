//During the test the env variable is set to test

//Require the dev-dependencies
let chai = require('chai');
let chaiHttp = require('chai-http');
let server = require('../server');
let should = chai.should();


chai.use(chaiHttp);

  describe('/panel', () => {
      it('it should GET all the panels', (done) => {
        chai.request(server)
            .get('/panel')
            .end((err, res) => {
                  res.should.have.status(200);
                  res.body.should.be.a('array');
                  res.body.length.should.be.eql(2);
              done();
            });
      });
  });

  describe('/panel', () => {
    it('it should not POST a panel without id', (done) => {
        let panel = {
            panel: "React",
            skills: "React",
            interviewer:"Yash",
            Active: true
        }
      chai.request(server)
          .post('/panel')
          .send(panel)
          .end((err, res) => {
                res.should.have.status(200);
                res.body.should.be.a('object');
                res.body.should.have.property('id').eql(3);
            done();
          });
    });

});
