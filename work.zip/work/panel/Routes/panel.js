const express = require('express'); //import express
const router  = express.Router(); 
const panel = require('./../Controller/panel');

router.get('/', panel.getPanel); 
router.get('/:skills', panel.getPanelBySkills)
router.post('/', panel.createPanel);
router.put('/:id',panel.updatePanel);
router.delete('/:id',panel.deletePanel);

module.exports = router; // export to use in server.js