const express = require('express'); //import express
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const p = require("passport");
const router  = express.Router(); 
const user = require('./../Controller/user');

router.get('/userinfo', user.userInfo);
router.post('/register', user.register);
router.post('/login', user.login);
router.get('/logout', user.logout);


module.exports = router; // export to use in server.js