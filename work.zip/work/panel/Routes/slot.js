const express = require('express'); //import express
const router  = express.Router(); 
const slot = require('./../Controller/slot');

router.post('/',slot.createSlot);
router.put('/:id', slot.updateSlot);
router.delete('/:id', slot.deleteSlot);
router.get('/unusedslots', slot.getUnusedSlot);
router.get('/highestslot', slot.getHighestSlot)

module.exports = router; // export to use in server.js