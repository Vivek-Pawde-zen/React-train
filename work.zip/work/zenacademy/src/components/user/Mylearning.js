import React from 'react'

export default function Mylearning() {
  return (
      <div style={{ padding: '8px', marginTop: '10px', color: "#2C3333", fontSize: "30Px", textAlign: "center" }}>My Learning</div>
  )
}

