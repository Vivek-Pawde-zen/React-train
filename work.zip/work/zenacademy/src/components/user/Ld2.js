import * as React from 'react';
import { DataGrid } from '@mui/x-data-grid';

const columns = [
  { field: 'id', headerName: 'ID', width: 70 },
  { field: 'courseName', headerName: 'Course name', width: 130 },
  { field: 'sgoName', headerName: 'SGO', width: 130 },
  {
    field: 'link',
    headerName: 'link',
    //type: 'number',
    width: 90,
  },
  {
    field: 'fullName',
    headerName: 'Full course ID',
    description: 'This column has a value getter and is not sortable.',
    sortable: false,
    width: 160,
    valueGetter: (params) =>
      `${params.row.courseName || ''} ${params.row.sgoName || ''}`,
  },
];

const rows = [
  { id: 1, sgoName: 'AES', courseName: 'JAVASCRIPT', link: 'Link1' },
  { id: 2, sgoName: 'Non-AES', courseName: 'REACT', link: 'Link2' },
  { id: 3, sgoName: 'DES', courseName: 'HTML', link: 'Link3' },
  { id: 4, sgoName: 'AMS', courseName: 'MICRO', link: 'Link3' },
  { id: 5, sgoName: 'AMS', courseName: 'BOOTSTRAP', link: 'Link4' },
  { id: 6, sgoName: 'DES', courseName: 'NODE', link: 'Link5' },
  { id: 7, sgoName: 'AES', courseName: 'MONGO', link: 'Link6' },
  { id: 8, sgoName: 'AES', courseName: 'SQL', link: 'Link7' },
  { id: 9, sgoName: 'AES', courseName: 'NOSQL', link: 'Link8' },
];

export default function DataTable() {
  return (
    <div style={{ height: 400, width: '100%', textAlign: "center",marginLeft: '80px'}}>
      <DataGrid
        rows={rows}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[5]}
        checkboxSelection
      />
    </div>
  );
}