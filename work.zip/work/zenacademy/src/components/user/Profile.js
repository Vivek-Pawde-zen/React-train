import React from 'react'

function Profile() {
  return (
      <div style={{ padding: '8px', marginTop: '10px', color: "#2C3333", fontSize: "30Px", textAlign: "center" }}>Profile</div>
  )
}

export default Profile