import { Box } from '@mui/system'
import React from 'react'


export default function Mycourse() {
  return (
<Box>
    <div style={{ padding: '8px', marginTop: '10px', color: "#2C3333", fontSize: "30Px", textAlign: "center" }}>SGO Course</div>
  </Box>
  )
}

