import * as React from 'react';
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Button from '@mui/material/Button';
//import Stack from '@mui/material/Stack';

export default function BasicSelect() {
  const [course, setCourse] = React.useState('');

  const handleChange = (event) => {
    setCourse(event.target.value);
  };

  return (
    <>
    <div style={{ padding: '8px', marginTop: '10px', color: "#2C3333", fontSize: "30Px", textAlign: "center" }}>Add Recording</div>
    <Box sx={{ maxWidth: 160, ml:'44%', marginBottom:'10px', zIndex: 'tooltip'}}>
      <FormControl fullWidth>
        <InputLabel id="demo-simple-select-label">Select Course</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={course}
          label="Course"
          onChange={handleChange}
        >
          <MenuItem value={10}>React.js</MenuItem>
          <MenuItem value={20}>Html</MenuItem>
          <MenuItem value={30}>Css</MenuItem>
        </Select>
      </FormControl>
    </Box>
    <Box sx={{ maxWidth: 160, ml:'44%', marginBottom:'10px', zIndex: 'tooltip'}}>
        <FormControl fullWidth>
          <InputLabel id="demo-simple-select-label">Select Link</InputLabel>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={course}
            label="Course"
            onChange={handleChange}
          >
            <MenuItem value={'https://www.youtube.com/watch?v=kUMe1FH4CHE'}>Html yt link</MenuItem>
            <MenuItem value={'https://www.youtube.com/watch?v=kUMe1FH4CHE'}>Css yt link</MenuItem>
            <MenuItem value={'https://www.youtube.com/watch?v=kUMe1FH4CHE'}>Js yt link</MenuItem>
          </Select>
        </FormControl>
    </Box>
    <Button variant="contained"sx={{ maxWidth: 160, ml:'46%', marginBottom:'10px', zIndex: 'tooltip'}}>Confirm</Button>  
    </>
    
  );
}

//////////////



