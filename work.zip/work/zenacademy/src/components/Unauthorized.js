import React from 'react'

const Unauthorized = () => {
  return (
    <div style={{textAlign:"center",color:"red",fontSize:"24px"}}>Unauthorized</div>
  )
}

export default Unauthorized