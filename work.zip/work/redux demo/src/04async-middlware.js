import { createSlice, configureStore, createAsyncThunk } from "@reduxjs/toolkit";
const callMe = () =>{
    // With Redux Tookit, Redux thunk is included by default,
    // allowing createAsyncThunk to perform delayed, asynchrnous logic before
    // sending the processed result to the reducers.

    const getUsers = createAsyncThunk(
        // action type string
        'users/getUsers',
        // callback function
        async(thunkApi,{rejectWithValue}) =>{
            try{
                const res = await fetch('http://jsonplaceholder.typicode.com/users')
                const data = await res.json();
                return data;
            }
            catch(err){
                return rejectWithValue('Oops, something went wrong!');
            }
        }
    )

    const user = {name:'Prasenjit',email:'prasentjit@gmail.com'};

    const addUser = createAsyncThunk(
        // action type string
        'users/addUser',
        // callback function
        async(thunkApi,{rejectWithValue}) =>{
            try{
                const res = await fetch('http://jsonplaceholder.typicode.com/users',
                {
                    method:'POST',
                    body:JSON.stringify(user),
                    headers:{'Content-Type':'application/json; charset:UTF-8'}
                })
                const data = await res.json();
                return data;
            }
            catch(err){
                return rejectWithValue('Oops, something went wrong!');
            }
        }
    )
    const fetchSlice = createSlice({
        name:'Fetch',
        initialState:{
            loading:false,
            entities:{},
            error:{}
        },
        reducers:{
    // standard reducer logic, with auto-generated types per reducer
        },
        extraReducers:{
            [getUsers.pending]: (state) =>{
                state.loading = true
            },
            [getUsers.fulfilled]: (state,action) =>{
                state.loading = false
                state.entities = action.payload
            },
            [getUsers.rejected]: (state,{err}) =>{
                state.loading = false
                state.error = err
            },
            [addUser.pending]: (state) =>{
                state.loading = true
            },
            [addUser.fulfilled]: (state,action) =>{
                state.loading = false
               console.log(action.payload);
            },
            [addUser.rejected]: (state,{err}) =>{
                state.loading = false
                console.error(err);
            }
        }
    })

    const store = configureStore({
        reducer: fetchSlice.reducer
    })

    store.subscribe(() => console.log(store.getState()));

    // dispatch the actions
    store.dispatch(getUsers())
    store.dispatch(addUser(user))
    
    console.log('\n');
}

export default callMe;