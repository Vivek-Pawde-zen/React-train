import {configureStore, createSlice} from '@reduxjs/toolkit';
import logger from 'redux-logger';

let callMe = () =>{

    const counterSlice = createSlice({
        name:'counter',
        initialState:{value:0},
        reducers:{
            increment: state =>{
                console.log('increment!');
                state.value += 1;
            },
            decrement: state =>{
                console.log('decrement!');
                state.value -= 1;
            }
        }
    })

    const {increment,decrement} = counterSlice.actions;

    
    // Custom Middleware - Logging
    const myLogger = (store) =>
                        (next) =>
                            (action) => {
                                console.log('Action fired ',action);
                                console.log('Original State ',store.getState());
                                next(action); // calling next middleware function
                            }
    
    let store = configureStore({
        reducer: counterSlice.reducer,
        //middleware:[myLogger,logger]
        // By default, configureStore adds some middleware to the Redux
        // store setup automatically

        // getDefaultMiddleware is useful if you want to add some custom
        // middlware but also still want to have the default middleware 
        // added
        middleware: (getDefaultMiddleware) =>(
            getDefaultMiddleware().concat(myLogger,logger)
        )
    })

    store.subscribe(() => console.log(store.getState()));

    // dispatch the actions
    store.dispatch(increment())
    store.dispatch(increment())
    store.dispatch(decrement())

    console.log('\n');
}

export default callMe;