import {configureStore, createSlice} from '@reduxjs/toolkit';

let callMe = () =>{

    const userSlice = createSlice({
        name:'user',
        initialState:{
            name:'',
            age:0
        },
        reducers:{
            changeName: (state,action)=>{
                state.name = action.payload
            },
            changeAge: (state,action)=>{
                state.age = action.payload
            }
        }
    })

    const {changeName,changeAge} = userSlice.actions;

    const tweetsSlice = createSlice({
        name:'tweets',
        initialState:{
            tweetsArr :[]
        },
        reducers:{
            addTweet: (state,action)=>{
                state.tweetsArr.push(action.payload)
            }
        }
    })

    const {addTweet} = tweetsSlice.actions;

    let store = configureStore({
        reducer: {
            userReducer: userSlice.reducer,
            tweetsReducer: tweetsSlice.reducer
        }
    })

    store.subscribe(() => console.log(store.getState()));


    console.log(store.getState());
    
    // dispatch the actions
    store.dispatch(changeName('Ashish'))
    store.dispatch(changeAge(22))
    store.dispatch(addTweet('This is my first tweet!'));
    store.dispatch(addTweet('Learn Flux and Redux!'));

    console.log('\n');
}

export default callMe;