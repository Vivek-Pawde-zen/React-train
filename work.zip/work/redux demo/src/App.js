import './App.css';
// import callMe from './00immutability';
// import callMe from './01basic-setup';
//import callMe from './02multipleReducers';
// import callMe from './03middleware';
import callMe from './04async-middlware';


function App() {
  callMe()
  return (
    <div className="App">
      <h1>Redux Demo</h1>
    </div>
  );
}

export default App;
