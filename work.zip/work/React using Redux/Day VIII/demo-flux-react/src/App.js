import './App.css';
import Todos from './todos';
//import Todo from './todo';
import Users from './users';

function App() {
  return (
    <div className='container'>
      {/* <h1>Hello World!</h1>
     <Todo complete={false} text='Prepare Presentation!'></Todo> */}
      <div className="row">
        <div className="col-md-6">
          <Todos />
        </div>
        <div className="col-md-6">
          <Users />
        </div>
      </div>
    </div>
  );
}

export default App;
