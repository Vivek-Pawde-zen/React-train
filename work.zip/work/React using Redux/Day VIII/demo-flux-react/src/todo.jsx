import React from 'react'
import { deleteTodoActionCreator } from './actions/todoactions';

// Presentational Component
export default class Todo extends React.Component {
    constructor(props) {
        super();
    }
    render() {

        const { complete, text } = this.props;// ES2015 - Destructuring
        const icon = complete ? "\u2714" : "\u2716"

        return (
            <li className='list-unstyled text-primary '
                style={{ maxWidth: 'fit-content', fontSize: 'x-large' }}
                onClick={() => {
                    console.log(this.props.id);
                    deleteTodoActionCreator(this.props.id);
                }}>
                <span>{text}</span>
                <span>{icon}</span>
            </li>
        )
    }
}