import dispatcher from '../dispatcher'
import axios from 'axios'

//delete
export function deleteTodoActionCreator(id) {   
    axios.delete(`http://localhost:8000/todos/${id}`)
        .then(res => {
            console.log(res);
            console.log(res.data);
            dispatcher.dispatch({ type: 'DELETE_TODO', response: res })
        })
}
// 5
// action creator
// post
export function createTodoActionCreator(text) {
    //dispatcher.dispatch({ type: 'CREATE_TODO', text });
    let todo =  { id: Date.now(), text: text, complete: false };
    axios.post(`http://localhost:8000/todos`, todo)
        .then(res => {
            console.log(res);
            console.log(res.data);
            dispatcher.dispatch({ type: 'CREATE_TODO', text: res.data.text })
        })
}

//get
//6 asynchronous action
export function reloadTodosActionCreator() {
    // // simulating Ajax
    // dispatcher.dispatch({ type: 'FETCH_TODOS' });
    // setTimeout(() => {
    //     dispatcher.dispatch({
    //         type: 'RECEIVE_TODOS',
    //         todos: [
    //             {
    //                 id: 8484848484,
    //                 text: "Do Warm up",
    //                 complete: false
    //             },
    //             {
    //                 id: 6262627272,
    //                 text: "Play Football",
    //                 complete: true
    //             },
    //             {
    //                 id: 9982388388,
    //                 text: "Run 10km",
    //                 complete: false
    //             },
    //             {
    //                 id: 78273882823,
    //                 text: "Go to Gym",
    //                 complete: true
    //             },
    //         ]
    //     })
    // }, 1000)

    // asynchronous call using axios
    axios.get(`http://localhost:8000/todos`)
        .then((response) => {
            dispatcher.dispatch({
                type: 'RECEIVE_TODOS', todos: response.data
            });
        }).catch((err) => {
            console.log(err.message)
        })
}

