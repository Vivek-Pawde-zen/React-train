import dispatcher from '../dispatcher';
import axios from 'axios'

// asynchronous action - axios - promise based http client
export function reloadUsersActionCreator() {

    // asynchronous call using axios
    axios.get(`https://jsonplaceholder.typicode.com/users`)
        .then((response) => {
            dispatcher.dispatch({
                type: 'RECEIVE_USERS', users: response.data
            });
        }).catch((err) => {
            console.log(err.message)
            dispatcher.dispatch({
                type: 'RECEIVE_ERROR', errorMsg: err.message
            });
        })
}