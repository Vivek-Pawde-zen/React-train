import React from 'react'

// Presentational Component
export default class User extends React.Component{
    constructor(props){
        super();
    }
    render(){        
        const {name,email} = this.props;// ES2015 - Destructuring       

        return (
            <li className='list-unstyled text-primary'>
                <b className='text-info'>Name </b> <span>{name}</span>
                <b className='text-info'>Email </b> <span>{email}</span>
            </li>
        )
    }
}