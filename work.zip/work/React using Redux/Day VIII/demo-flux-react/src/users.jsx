import React from 'react'
import { reloadUsersActionCreator } from './actions/useractions';
import userStore from './stores/userstore';
import User from './user'

// Controller View / Container Component
export default class Todos extends React.Component {
    constructor() {
        super();
        this.state = {
            users: userStore.getAllUsers(),
            errorMsg:userStore.getError()
        }
        //3 // binding
        this.getUsers = this.getUsers.bind(this);
        this.getError = this.getError.bind(this);
    }
    getUsers() {
        this.setState({ users: userStore.getAllUsers() });

    }
    getError() {
        this.setState({ errorMsg: userStore.getError() });
    }
    componentDidMount() {
        // Subscribe to the change event of userStore
        userStore.on('change', this.getUsers);
        userStore.on('errorEvent', this.getError);
    }
    componentWillUnmount() {
        // UnSubscribe to the change event of userStore
        userStore.removeListener('change', this.getUsers);
        userStore.removeListener('errorEvent', this.getError);
    }

    reloadUsersFun() {
        reloadUsersActionCreator();
    }

    render() {
        // 1
        const { users } = this.state; // Destructuring
        const UserComponents = users.map((user) => {
            return <User key={user.id} {...user} />
        })
        return (
            <div>
                <h4 style={
                    {   
                        color:'black',
                        marginLeft:'50px',
                        fontStyle:'bolder',
                        textShadow:'5px 5px 5px gray'}}>Users from jsonplaceholder.typecode.com</h4>
                <button onClick={this.reloadUsersFun.bind(this)} className='btn btn-warning btn-outline-dark'
                    style={{ margin: '10px' }}>Reload Users!</button>
                {/* 1 */}
                <h1 className='display-1'
                style={{textShadow:'5px 8px 5px maroon'}}>Users</h1>
                <ul>{UserComponents}</ul>      
                <h1 className='display-1 text-danger'>{this.state.errorMsg}</h1>          
            </div>
        )
    }
}