import React from 'react'
import { createTodoActionCreator, reloadTodosActionCreator } from './actions/todoactions';
import todoStore from './stores/todostore';
import Todo from './todo'

// Controller View / Container Component
export default class Todos extends React.Component {
    constructor() {
        super();
        this.state = {

            //     // 1
            //     todos: [
            //         {
            //             id: 111123213124,
            //             text: 'Go Shopping',
            //             complete: false
            //         },
            //         {
            //             id: 2323223213124,
            //             text: 'Do Strength Training',
            //             complete: true
            //         },
            //         {
            //             id: 4343423213124,
            //             text: 'Play Cricket',
            //             complete: false
            //         }
            //     ]
            // }

            //2 // Controller View grabbing the state from the stores
            todos: todoStore.getAll(),
            val: ''
        }
        //3 // binding
        this.getTodos = this.getTodos.bind(this);
    }
    // 3 Event Listener
    getTodos() {
        this.setState({ todos: todoStore.getAll() });
    }
    //3 
    componentDidMount() {
        //reloadTodosActionCreator(); // or in useEffect
        // Subscribe to the change event of todoStore
        todoStore.on('change', this.getTodos);
    }
    //3
    componentWillUnmount() {
        // UnSubscribe to the change event of todoStore
        todoStore.removeListener('change', this.getTodos);
    }
    // 5
    handleChange(evt) {
        this.setState({ val: evt.target.value });
    }

    //5
    createTodoFun() {
        let txt = document.getElementById('todoInput').value;
        createTodoActionCreator(txt);
        this.setState({ val: '' });
        document.getElementById('todoInput').focus();
    }

    //6
    reloadTodosFun() {
        // giving call to action creator
        reloadTodosActionCreator();
    }

    render() {
        // 1
        const { todos } = this.state; // Destructuring
        const TodoComponents = todos.map((todo) => {
            return <Todo key={todo.id} {...todo} />
        })
        return (
            <div>
                {/* 5 */}
                <span style={{fontWeight:'bolder'}}>Todo</span>:- <input type='text' id='todoInput'
                    value={this.state.val}
                    onChange={this.handleChange.bind(this)} /> <br />
                <button onClick={this.createTodoFun.bind(this)} className='btn btn-warning btn-outline-dark'
                    style={{ margin: '10px' }}>Create Todo!</button>
                {/* 6 */}
                <button onClick={this.reloadTodosFun.bind(this)} className='btn btn-warning btn-outline-dark'
                    style={{ margin: '10px' }}>Reload Todos!</button>
                {/* 1 */}
                <h1 className='display-1'
                    style={{ textShadow: '5px 8px 5px indigo' }}>Todos</h1>
                <h4
                style={
                    {
                        color:'black',
                        marginLeft: '50px',
                        fontStyle: 'bolder',
                        textShadow: '5px 5px 5px gray'
                    }}>Click on any todo to delete it!</h4>
                <ul>{TodoComponents}</ul>
            </div>
        )
    }
}