import { EventEmitter } from 'events';
import { reloadTodosActionCreator } from '../actions/todoactions';
import dispatcher from '../dispatcher';

//2
class TodoStore extends EventEmitter {
    constructor() {
        super();
        this.todos = [
            {
                id: 111123213124,
                text: 'Go Swimming',
                complete: false
            },
            {
                id: 4343423213124,
                text: 'Play Chess',
                complete: true
            }
        ]        
    }
    getAll() {
        return this.todos;
    }
    createTodo(text) {
        // const id = Date.now();
        // this.todos.push({
        //     id,
        //     text,
        //     complete: false
        // })
        this.todos = this.getAll();
        // To Refresh
        reloadTodosActionCreator()
        // 3
        // publisher - publishing an event
        this.emit('change'); // raising a change event
        console.log(this.todos);
    }

    // Callback function registered with dispatcher
    handleActions(action) {
        console.log('TodoStore received an action ', action);
        switch (action.type) {
            case 'CREATE_TODO':
                console.log('Response Todo '+action.text)
                this.createTodo(action.text);
                break;
            case 'RECEIVE_TODOS':
                this.todos = action.todos;
                this.emit('change');
                break;
            case 'DELETE_TODO':
                    console.log(action.response);
                     // To Refresh
                     reloadTodosActionCreator()
                    this.emit('change');
                    break;
            default:
                console.log('default case!')
                break;
        }
    }
}

//2
const todoStore = new TodoStore();
// Exposing todoStore object to the browser's window
// window.todoStore = todoStore;
// todoStore.createTodo('Watch Movie');

//4 dispatcher
dispatcher.register(todoStore.handleActions.bind(todoStore));
// Exposing the dispatcher object to the browser window
// window.dispatcher = dispatcher;
// dispatcher.dispatch({type:'CREATE_TODO',text:'Watch Movie'})

//5 actions - So no need to expose store or dispatcher to the browser window

export default todoStore;