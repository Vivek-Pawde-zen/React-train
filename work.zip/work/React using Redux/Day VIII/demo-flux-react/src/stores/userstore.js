import { EventEmitter } from 'events';
import dispatcher from '../dispatcher';

class UserStore extends EventEmitter {
    constructor() {
        super();
        this.users = []
        this.errorMsg = ''
    }
    getAllUsers() {
        return this.users;
    }
    getError() {
        return this.errorMsg;
    }
    // Callback function registered with dispatcher
    handleActions(action) {
        console.log('UserStore received an action ', action);
        switch (action.type) {
            case 'RECEIVE_USERS':
                this.users = action.users;
                this.emit('change');
                break;
            case 'RECEIVE_ERROR':
                this.errorMsg = action.errorMsg;
                console.log('Error ' + this.errorMsg)
                this.emit('errorEvent');
                break;
            default:
                console.log('default case!')
                break;
        }
    }
}


const userStore = new UserStore();

dispatcher.register(userStore.handleActions.bind(userStore));

export default userStore;