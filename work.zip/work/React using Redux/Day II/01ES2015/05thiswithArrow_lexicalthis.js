// // ES 5

// // class /ctor
// function Person() {
//     this.age = 0;// 'this' belongs to Person class
//     setInterval(function growUp(){
//         this.age++; // 'this' belongs to growUp class
//         console.log(this.age);
//     },1000);
// }

// var p1 = new Person();
// console.log(p1.age);

// // ES 5 - 1 using another variable to store 'this'
// function Person() {
//     var that = this; // 'this' belongs to Person class
//     that.age = 0;
//     setInterval(function growUp(){
//         that.age++; 
//         console.log(that.age);
//     },1000);
// }

// var p1 = new Person();
// console.log(p1.age);

// // ES 5 - 2 using bind() function

// function Person() {
//     this.age = 0;// 'this' belongs to Person class
//     setInterval(function growUp(){
//         this.age++;
//         console.log(this.age);
//     }.bind(this),1000);
// }

// var p1 = new Person();
// console.log(p1.age);

// ES 2015 - 3 Arrow Function - it retain the context of outer 'this'

function Person() {
    this.age = 0;// 'this' belongs to Person class
    setInterval(() =>{
        this.age++;// 'this' belongs to Person class
        console.log(this.age);
    },1000);
}

var p1 = new Person();
console.log(p1.age);