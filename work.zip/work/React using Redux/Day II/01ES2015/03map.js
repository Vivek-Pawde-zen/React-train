// map is a key value pair
// any value (both object / primitive type)
// can be used as a key or as a value

// value can be duplicated but not the key.

let m = new Map();
m.set('hello', 5);
m.set(2, 3);

console.log(m.get('hello'))
console.log(m.get(2))
console.log(m.size === 2)

m.set('abc', 5)
console.log(m.get('abc'))
m.set(2, 55)
console.log(m.get(2))

let keyString = 'a string'
let keyObject = {}
let keyFunction = function () { }

m.set(keyString, "Value associated with 'a string'")
m.set(keyObject, "Value associated with 'an object'")
m.set(keyFunction, "Value associated with 'a function'")

console.log('\n')

for (let [key, val] of m.entries()) {
    console.log(key + ' ' + val)
}