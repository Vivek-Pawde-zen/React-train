// Spread Operator - Spreading of an elements of an iterable collection
// into literal elements and into individual function parameters.

let arr1 = [1, 2, 3];
let arr2 = [11, 22, 33];

//let arr3 = [arr1,arr2];// Array of array
let arr3 = [...arr1, ...arr2];

// for(let i in arr3){
//     console.log(arr3[i]);
// }

function doStuff(x, y, z) {
    console.log('x ' + x + ' y ' + y + ' z ' + z);
}

doStuff(1, 2, 3);
let arr = [5, 6, 7];
doStuff(...arr);

// For Object
let obj1 = { foo: 'bar', x: 10 };
let obj2 = { bar: 'foo', y: 20 };

console.log(obj1);
console.log(obj2);

let obj3 = { ...obj1, ...obj2 };
console.log(obj3);

// Whenever you are using ... (ellipsis) on the right hand side of an assignment operator
// then that is Spread Operator.

// Whenever you are using ... (ellipsis) on the left hand side of an assignment operator
// then that is REST Parameter.