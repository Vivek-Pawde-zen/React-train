// Arrow Functions / Lambda Expression

let multiplySimple = function(x,y){
    return x*y;
}
console.log('\n')
console.log('Result is '+multiplySimple(4,5));

// Arrow Function

let multiply = (x,y) => x*y; // Expression that by default returns a value

console.log('\n')
console.log('Result is '+multiply(4,5));

let add = (x,y) => {
                        console.log('Inside add!');
                        console.log('Addition is '+(x+y));
                        return x+y;
                    }
console.log('\n')
console.log('Result is '+add(4,5));

let foo = () =>  "Inside Foo!";

console.log('\n')
console.log(foo());