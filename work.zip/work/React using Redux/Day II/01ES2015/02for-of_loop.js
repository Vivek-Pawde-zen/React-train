let arr = [11,22,33,44,55];

// ES5
// for, while, do-while and for-in loop


// ES5
console.log('\nusing for loop');
for(var i=0; i<arr.length;i++){
    console.log(arr[i]);
}
console.log('\nusing for-in loop');
for(var i in arr){
    console.log(arr[i]); // i is still a loop counter
}

// ES2015
// for-of loop - foreach loop in another programming languages

console.log('\nusing for-of loop');
for(let ele of arr){
    console.log(ele); // ele is actual element and you can't modify arr with ele
}
