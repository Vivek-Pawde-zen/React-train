import './App.css';
import CheckBox, { Counter } from './checkbox';
import Greet, { HelloMsg } from './greet_props';
import BruceImage, { Hello } from './hello';
import welcome, { WelcomeII } from './welcome';

// Functional Component
function App() {
  return (
    // <div className="App">
    //   <h2>Hello World!</h2>
    //   <Hello />
    //   <br/>
    //   <BruceImage />
    //   <br/>
    //   {welcome}
    //   <br/>
    //   <WelcomeII />
    // </div>

    // <div className="App">
    //       <Greet />
    //       <Greet name='Ashish'/>
    //       <Greet name='Aditya'/>
    //       <br/>
    //       <h1>Heading 1</h1>
    //       <br/>
    //       <HelloMsg text='India'>Welcome to India!</HelloMsg>
    //       <HelloMsg text='World'>Welcome to World!</HelloMsg>
    //       <HelloMsg text='Universe'>Welcome to Universe!</HelloMsg>
    // </div>
    <div style={{padding:'40px'}}>
          <CheckBox />      
          <br/>
          <br/>
          <br/>
          <Counter />   
    </div>
  );
}

export default App;
