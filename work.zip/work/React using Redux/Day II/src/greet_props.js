import React from "react";

//props - properties

// props are there to hold some information as well as to display(represent) that information.
// For props data or information generally coming from the parent component.

// props are immutable.

// class component 
// class Greet extends React.Component{
//     render(){
//         return <h1 className='text-center'>Welcome {this.props.name}!</h1>
//     }

//     // static getter for defaultProps
//     static get defaultProps(){
//         return {
//             name:'Nyra'
//         }
//     }
// }
// // Older way of defaultProps
// // Greet.defaultProps = {
// //     name:'Ovee'
// // }
// export default Greet;

// functional component
const name='Abhijeet';

function Greet(props){ 
     return (
         (props.name)
         ?<h1 className='text-center text-success'>Welcome {props.name}!</h1>
         :<h1 className='text-center text-warning'>Welcome {name}!</h1>
     )
}
export default Greet;

// // class component
// // built-in prop - children
// export class HelloMsg extends React.Component{
//     render(){
//         return  <div>
//                     <h1 className='text-center display-1'>Hello {this.props.text}!</h1>
//                     {/* built-in props - children to render child inside the component */}
//                     <h3 className='text-center text-danger display-3'>{this.props.children}</h3>
//                 </div>
//     }
// }

// class component
// built-in prop - children
export function HelloMsg(props){
        return  <div>
                    <h1 className='text-center display-1'>Hello {props.text}!</h1>                    
                    <h3 className='text-center text-danger display-3'>{props.children}</h3>
                </div>    
}