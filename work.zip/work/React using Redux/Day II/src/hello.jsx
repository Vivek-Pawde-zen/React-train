import React from 'react';

// class component
// export class Hello extends React.Component{
//     render(){
//         return <h1 id='hOne'>Hello World - using create-react-app!</h1>
//     }
// }

// functional component
export function Hello(){
        return <h1 id='hOne'>Hello World - using create-react-app! functional Component!</h1>    
}

// //class component
// export default class BruceImage extends React.Component{
//     render(){
//         return <img src='bruce.jpg' alt='Burce Lee'></img>
//     }
// }

//functional component
export default function BruceImage(){    
        return <img src='bruce.jpg' alt='Burce Lee'></img>
}

// functional component - recommended
// Benefits
// Code is easier to read and understand
// Easy to debug
// Easy to test - don't have to worry about any hidden state
// Better in performance - No State, No Lifecycle hooks/ methods
