import React from 'react';
//import './welcome.css';
// CSS Module
import styles from './welcome.module.css';

// const x = 5;
// export default x;

const hStyle = {
    fontSize:'15px',
    border:'5px dashed Navy',
    color:'red'
}

const welcome = (
    <div>
        {/* CSS from .css file */}
        {/* <h1 className='myClass'>Welcome to React.js!</h1><br/>
        <h3 className='myClass'>Result of 4 * 5 is {4*5}!</h3> */}
        
        {/* Inline css */}
         <h1 style={hStyle} >Welcome to React.js!</h1><br/>

        {/* css from css modules */}
        <h3 className={styles.myClass}>Result of 4 * 5 is {4*5}!</h3>
    </div>
)

export default welcome;

export function WelcomeII(){
    // Inline CSS
    return <h1 style={{color:'red',backgroundColor:'palegreen'}}>Hello from Functional Component!</h1>
}
