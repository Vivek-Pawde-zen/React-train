// import React from 'react';

// // State

// // Like props state also holds the information about the component
// // but the kind of information and how do you handle it 
// // that is going to be different than the props.

// // State is changable.


// class CheckBox extends React.Component{
//     constructor(){
//         super(); // call to the base/super class - it is mandatory if your class is inherited from another class
//         // maintaing one state 'checked' here
//         this.state = {checked:true};

//         //1 Binding CheckBox 'this' with handleChange method
//         // this.handleChange = this.handleChange.bind(this);
//     }
//     // Event listener for change event of a checkbox
//     handleChange(){
//         console.log('handleChange!');

//         // Modify the state

//         // You shouldn't modify the state directly, always use setState method.
//         // this.state.checked = !this.state.checked;

//         // Synchronous Version of setState
//         // this.setState({checked:!this.state.checked});

//         // Asynchronous Version of setState
//         this.setState((prevState,props) =>{
//             return {checked: !prevState.checked}
//         })
//     }
//     render(){
//         let msg = '';
//         if(this.state.checked){
//             msg ='Checked';
//         }
//         else{
//             msg = 'Unchecked';
//         }
//         return (
//             // Synthetic Events - Cross Browser events works identical.
//             // support event pooling.
//             <div>
//                 <input type='checkbox' defaultChecked='true'

//                 // 1 In CTOR
//                 //onChange={this.handleChange}/>

//                 // 2
//                 //onChange={this.handleChange.bind(this)}/>

//                 // 3 using Arrow Function
//                 onChange={ () =>{
//                     //this.setState({checked:!this.state.checked});
//                     this.handleChange();
//                 }}/>

//                 <h1>The box is '<b className='text-danger'>{msg}</b>'!</h1>
//             </div>
//         )
//     }
// }

// export default CheckBox;

import React, { useState } from 'react';

// functional component
function CheckBox() {
    // React Hooks - 16.8 onwards
    //  const [stateValue, updaterFn] = useState(initialStateValue);
    const [checked,setChecked] = useState(true);

    let msg = '';
    if (checked) {
        msg = 'Checked';
    }
    else {
        msg = 'Unchecked';
    }
    return (
        <div>
            <input type='checkbox' defaultChecked='true'
               onChange={() => setChecked(!checked)} />

            <h1>The box is '<b className='text-danger'>{msg}</b>'!</h1>
        </div>
    )
}

export default CheckBox;

const buttonStyle = {
    color:'maroon',
    backgroundColor:'peachpuff',
    fontSize:'x-large',
    margin:'10px'
}

const pStyle = {    
    marginLeft:'100px',
    fontSize:'xx-large',
    maxWidth:'fit-content'
}
export function Counter(){
    // useState react hook
    const [count,setCounter] = useState(0);       

    return(
        <div style={{ border: 'solid 10px gray', maxWidth: 'fit-content' }}>
            <p style={pStyle}>Counter <b style={{ fontWeight: 'bolder', color: 'maroon' }}>{count}</b></p>
            <button style={buttonStyle} onClick={() => setCounter(count+1)}>
                Increment!
            </button>
            <button style={buttonStyle} onClick={() => setCounter(count-1)}>
                Decrement!
            </button>
        </div>
    )
}