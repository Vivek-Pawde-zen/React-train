// //es5
// var x = 5;// number

// // es2015
// let a = 5;
// var b = 6;

// let str ="str"; // string
// let ch='A';// string

// var g = 9;// global variable

function foo(){
    var l = 6;// local variable
    //var d; // variable declaration is getting hoisted at the begining of the function.
    //console.log('g '+g+' l '+l);
    console.log('g '+g+' l '+l+' d '+d);
    {
        var d = 7;//function level scope
        //d = 7; // it is being assigned with the value
        //let d = 7;//block level scope
        //const d = 7;//block level scope + value can not be changed
    }
    console.log('g '+g+' l '+l+' d '+d);
}

//foo();


let x = 6;
const y = 7;

x++;
//y++;

const player = {
    ODIRuns : 5000,
    TESTRuns:10000
}

player.ODIRuns = 7000;

console.log(player)

//player = {}

