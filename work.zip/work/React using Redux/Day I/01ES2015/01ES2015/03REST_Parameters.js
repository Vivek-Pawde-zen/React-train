// ES2015 - REST Parameter

// REST Parameter - Aggregation of remaining parameters into a single variable

function log(message,what,...where){
    console.log('\n')
    console.log(message)
    console.log(what)
    console.log(where)
}

log('Hello');
log('Hello','How are you?');
log('Hello','How are you?','Where are you?');
log('Hello','How are you?','Where are you?','One more parameter!');
log('Hello','How are you?','Where are you?','One more parameter!','Second additional parameter!');
