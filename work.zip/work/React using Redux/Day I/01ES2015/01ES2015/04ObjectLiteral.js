function calculateService(){
    var add = function(x,y){
        console.log('Addition is '+(x+y));
    }
    var mult = function(x,y){
        console.log('Multiplication is '+x*y);
    }
    // // ES5
    // return {
    //     add:add,
    //     mult:mult
    // }
    
    // ES2015
       return {
        add,
        mult
    }
}

var obj = calculateService();
obj.add(4,5);
obj.mult(4,5);
