// // ES5
// function add(x,y){
//     x = x || 0;
//     y = y || 0;
//     return x+y;
// }

// ES2015
function add(x=0,y=0){
    return x+y;
}

// In javascript by default each and every function is variable argument function
console.log(add());
console.log(add(4));
console.log(add(4,5));


