// Destructuring - Javascript Expresion that makes it possible to unpack
// values from the array and unpack properties from the object into distinct values

function calculateService(){
    var add = function(x,y){
        console.log('Addition is '+(x+y));
    }
    var mult = function(x,y){
        console.log('Multiplication is '+(x*y));
    }
    var sub = function(x,y){
        console.log('Substraction is '+(x-y));
    }
    var div = function(x,y){
        console.log('Division is '+(x/y));
    }
    // ES2015
       return {
        add,
        mult,
        sub,
        div
    }
}
// var obj = calculateService();
// obj.add(4,5);
// obj.sub(14,10);

// var add = calculateService().add;
// add(4,5);

// // Destructuring
// var {add, mult} = calculateService();// Importing only add and mult

// add(4,5);
// mult(4,5);
// //sub(4,5);

let arr = [11,22,33,44,55]; // array

let [x,y,z] = arr;

console.log('x '+x+' y '+y+' z '+z);