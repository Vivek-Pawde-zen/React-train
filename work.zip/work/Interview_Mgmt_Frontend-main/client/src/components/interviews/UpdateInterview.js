import React from 'react'

const UpdateInterview = () => {

  //depending on role allow user to update specific fields like techRating,comments accessible to him/her.
  //otherwise follow same process metion in edit candidates 
  return (
    <div>UpdateInterview</div>
  )
}

export default UpdateInterview