import React from 'react'

const Panel = () => {
  return (
    <div>Panel</div>
  )
}

export default Panel