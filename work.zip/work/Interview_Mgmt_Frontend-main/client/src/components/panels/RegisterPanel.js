import React from 'react'

const RegisterPanel = () => {
  return (
    <div>RegisterPanel</div>
  )
}

export default RegisterPanel