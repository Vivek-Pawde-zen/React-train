import React from 'react'

const EditPanel = () => {
  return (
    <div>EditPanel</div>
  )
}

export default EditPanel