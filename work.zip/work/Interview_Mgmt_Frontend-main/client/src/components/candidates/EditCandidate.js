import React from 'react'

const EditCandidate = () => {
  return (
    <div>EditCandidate</div>
  )
}

export default EditCandidate