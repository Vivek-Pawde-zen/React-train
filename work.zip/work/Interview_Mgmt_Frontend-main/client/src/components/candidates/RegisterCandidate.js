import React from 'react'

const RegisterCandidate = () => {
  return (
    <div>RegisterCandidate</div>
  )
}

export default RegisterCandidate