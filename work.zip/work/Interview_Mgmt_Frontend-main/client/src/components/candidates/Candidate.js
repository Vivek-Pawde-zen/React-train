import React from 'react'

const Candidate = () => {
  return (
    <div>Candidate</div>
  )
}

export default Candidate