import React from 'react'

const Interviewer = () => {
  return (
    <div>Interviewer</div>
  )
}

export default Interviewer